﻿using System;
using System.Data.SqlClient;
using System.Drawing; // 用于 Color

public partial class AddTeacher : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // 权限验证
        if (Session["Role"] == null || Session["Role"].ToString() != "Admin")
            Response.Redirect("Login.aspx");

        if (!IsPostBack)
        {
            // [关键修复] 设置用户名显示
            lblUser.Text = Session["User"] != null ? Session["User"].ToString() : "Admin";
        }
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        string no = txtWorkNo.Text.Trim();
        string name = txtName.Text.Trim();
        string phone = txtPhone.Text.Trim();

        // 基础验证
        if (string.IsNullOrEmpty(no) || string.IsNullOrEmpty(name))
        {
            lblMsg.Text = "⚠️ ID and Name are required.";
            lblMsg.ForeColor = Color.Red;
            return;
        }

        // 默认密码 123456
        string sql = "INSERT INTO Teachers (WorkNo, Name, Phone, Password) VALUES (@no, @na, @ph, '123456')";

        try
        {
            SqlHelper.ExecuteNonQuery(sql,
                new SqlParameter("@no", no),
                new SqlParameter("@na", name),
                new SqlParameter("@ph", phone));

            // 成功提示
            lblMsg.Text = "✅ Faculty Registered! Default Pwd: 123456";
            lblMsg.ForeColor = Color.LimeGreen;

            // 清空并聚焦
            txtWorkNo.Text = "";
            txtName.Text = "";
            txtPhone.Text = "";
            txtWorkNo.Focus();
        }
        catch (Exception ex)
        {
            // 错误处理 (主键冲突等)
            if (ex.Message.Contains("PRIMARY KEY"))
            {
                lblMsg.Text = "❌ Error: Employee ID already exists.";
            }
            else
            {
                lblMsg.Text = "❌ System Error: " + ex.Message;
            }
            lblMsg.ForeColor = Color.Red;
        }
    }

    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session.Clear();
        Response.Redirect("Login.aspx");
    }
}