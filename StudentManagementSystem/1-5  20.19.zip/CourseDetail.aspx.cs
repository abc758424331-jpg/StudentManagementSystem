﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CourseDetail : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["User"] == null)
        {
            Response.Redirect("Login.aspx");
            return;
        }

        if (!IsPostBack)
        {
            if (Request.QueryString["cid"] != null)
            {
                string cid = Request.QueryString["cid"];
                LoadCourseInfo(cid);
                LoadComments(cid);
            }
            else
            {
                lblCourseName.Text = "参数错误";
                btnPost.Enabled = false;
            }
        }
    }

    private void LoadCourseInfo(string cid)
    {
        string sql = @"
            SELECT c.CourseName, c.Credit, c.CourseType, t.Name as TeacherName,
            (SELECT COUNT(*) FROM Scores WHERE CourseId = c.CourseId) as StuCount
            FROM Courses c
            LEFT JOIN Teachers t ON c.TeacherId = t.TeacherId
            WHERE c.CourseId = @cid";

        DataTable dt = SqlHelper.ExecuteQuery(sql, new SqlParameter("@cid", cid));
        if (dt.Rows.Count > 0)
        {
            DataRow dr = dt.Rows[0];
            lblCourseName.Text = dr["CourseName"].ToString();
            lblCredit.Text = dr["Credit"].ToString();
            lblType.Text = dr["CourseType"].ToString();
            lblTeacher.Text = dr["TeacherName"].ToString();
            lblStudentCount.Text = dr["StuCount"].ToString();
        }
    }

    private void LoadComments(string cid)
    {
        string sql = @"
            SELECT cm.Content, cm.PostTime, s.Name as StudentName
            FROM CourseComments cm
            JOIN Students s ON cm.StudentId = s.StudentId
            WHERE cm.CourseId = @cid
            ORDER BY cm.PostTime DESC";

        DataTable dt = SqlHelper.ExecuteQuery(sql, new SqlParameter("@cid", cid));

        if (dt.Rows.Count > 0)
        {
            rptComments.DataSource = dt;
            rptComments.DataBind();
            lblEmpty.Visible = false;
        }
        else
        {
            rptComments.DataSource = null;
            rptComments.DataBind();
            lblEmpty.Visible = true;
        }
    }

    protected void btnPost_Click(object sender, EventArgs e)
    {
        string content = txtComment.Text.Trim();
        string cid = Request.QueryString["cid"];
        string uid = Session["UserId"] != null ? Session["UserId"].ToString() : "0";

        if (string.IsNullOrEmpty(content)) return;

        if (Session["Role"] != null && Session["Role"].ToString() == "Student")
        {
            string sql = "INSERT INTO CourseComments (CourseId, StudentId, Content) VALUES (@cid, @uid, @txt)";

            try
            {
                SqlHelper.ExecuteNonQuery(sql,
                    new SqlParameter("@cid", cid),
                    new SqlParameter("@uid", uid),
                    new SqlParameter("@txt", content));

                txtComment.Text = "";
                LoadComments(cid);
            }
            catch (Exception ex)
            {
                // [修复] 使用 string.Format 替代字符串插值
                string msg = string.Format("alert('发布失败: {0}');", ex.Message.Replace("'", ""));
                ScriptManager.RegisterStartupScript(this, GetType(), "alert", msg, true);
            }
        }
        else
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "alert", "alert('提示：目前仅限学生发表评价。');", true);
        }
    }
}