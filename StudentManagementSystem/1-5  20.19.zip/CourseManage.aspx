﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="CourseDetail.aspx.cs" Inherits="CourseDetail" MaintainScrollPositionOnPostback="true" %>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" data-theme="dark">
<head runat="server">
    <title>课程详情与反馈 | 智慧教务系统</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&family=Rajdhani:wght@500;700&display=swap" rel="stylesheet">
    
    <style>
        /* === 1. 基础主题 (继承之前的风格，但去除游戏化元素) === */
        :root {
            --ease-smooth: cubic-bezier(0.25, 0.46, 0.45, 0.94);
        }

        [data-theme="dark"] {
            --bg-color: #0f172a;
            --bg-gradient: radial-gradient(circle at 50% 50%, #1e293b 0%, #0f172a 100%);
            --glass-panel: rgba(30, 41, 59, 0.7);
            --glass-border: rgba(255, 255, 255, 0.1);
            --text-main: #f8fafc;
            --text-sub: #94a3b8;
            --primary: #0ea5e9; /* 智慧蓝 */
            --primary-glow: rgba(14, 165, 233, 0.3);
            --input-bg: rgba(15, 23, 42, 0.6);
        }

        [data-theme="light"] {
            --bg-color: #f8fafc;
            --bg-gradient: linear-gradient(135deg, #e2e8f0 0%, #f8fafc 100%);
            --glass-panel: rgba(255, 255, 255, 0.85);
            --glass-border: rgba(203, 213, 225, 0.6);
            --text-main: #1e293b;
            --text-sub: #475569;
            --primary: #0284c7;
            --primary-glow: rgba(2, 132, 199, 0.2);
            --input-bg: rgba(255, 255, 255, 0.8);
        }

        body {
            margin: 0; padding: 0;
            background: var(--bg-color); background-image: var(--bg-gradient);
            color: var(--text-main); font-family: 'Inter', sans-serif;
            overflow-x: hidden; min-height: 100vh;
            transition: background 0.6s ease, color 0.6s ease;
        }

        #particle-canvas { position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: -1; opacity: 0.5; }

        /* === 2. 导航栏 (保持一致) === */
        .navbar {
            height: 70px; padding: 0 40px; display: flex; align-items: center; justify-content: space-between;
            background: var(--glass-panel); border-bottom: 1px solid var(--glass-border);
            backdrop-filter: blur(20px); position: fixed; top: 0; width: 100%; z-index: 1000; box-sizing: border-box;
        }
        .brand { font-family: 'Rajdhani', sans-serif; font-weight: 700; font-size: 24px; color: var(--text-main); text-decoration: none; }
        .brand i { color: var(--primary); }
        .btn-back {
            color: var(--text-sub); text-decoration: none; font-size: 14px; display: flex; align-items: center; gap: 8px;
            padding: 8px 16px; border: 1px solid var(--glass-border); border-radius: 8px; transition: 0.3s;
        }
        .btn-back:hover { background: var(--glass-border); color: var(--text-main); }

        /* === 3. 主布局 === */
        .container { max-width: 1000px; margin: 100px auto 40px; padding: 0 20px; display: flex; flex-direction: column; gap: 30px; }

        /* 课程信息卡片 */
        .course-header {
            background: var(--glass-panel); border: 1px solid var(--glass-border);
            border-radius: 20px; padding: 30px; position: relative; overflow: hidden;
            display: flex; justify-content: space-between; align-items: center;
            box-shadow: 0 20px 40px -10px rgba(0,0,0,0.1);
        }
        .course-header::before {
            content: ''; position: absolute; left: 0; top: 0; height: 100%; width: 4px; background: var(--primary);
        }
        .course-title h1 { margin: 0; font-size: 28px; font-weight: 700; }
        .course-info { margin-top: 8px; color: var(--text-sub); font-size: 14px; display: flex; gap: 20px; }
        .tag { background: rgba(14, 165, 233, 0.1); color: var(--primary); padding: 4px 10px; border-radius: 6px; font-size: 12px; font-weight: 600; }

        /* === 4. 全息留言板 (Holo-Board) === */
        .discussion-area {
            background: transparent; 
        }
        .section-title { font-size: 18px; font-weight: 600; margin-bottom: 20px; display: flex; align-items: center; gap: 10px; }
        .section-title i { color: var(--primary); }

        /* 留言输入框 */
        .input-panel {
            background: var(--glass-panel); border: 1px solid var(--glass-border);
            border-radius: 16px; padding: 20px; margin-bottom: 30px;
            display: flex; gap: 15px; align-items: flex-start;
            transition: 0.3s;
        }
        .input-panel:focus-within { border-color: var(--primary); box-shadow: 0 0 20px var(--primary-glow); }
        
        .avatar-box {
            width: 40px; height: 40px; border-radius: 50%; background: linear-gradient(135deg, var(--primary), #6366f1);
            display: flex; align-items: center; justify-content: center; color: #fff; font-weight: 700; font-size: 14px; flex-shrink: 0;
        }
        
        .comment-input {
            width: 100%; background: transparent; border: none; color: var(--text-main);
            font-family: 'Inter', sans-serif; font-size: 14px; resize: none; outline: none; min-height: 40px;
        }
        
        .btn-post {
            background: var(--primary); color: #fff; border: none; padding: 8px 20px;
            border-radius: 8px; cursor: pointer; font-weight: 600; font-size: 13px;
            transition: 0.3s; white-space: nowrap;
        }
        .btn-post:hover { transform: translateY(-2px); box-shadow: 0 5px 15px var(--primary-glow); }

        /* 留言列表 */
        .comment-list { display: flex; flex-direction: column; gap: 15px; }
        
        .comment-card {
            background: var(--glass-panel); border: 1px solid var(--glass-border);
            border-radius: 12px; padding: 15px 20px;
            display: flex; gap: 15px; animation: slideIn 0.4s ease-out;
            transition: 0.3s;
        }
        .comment-card:hover { transform: translateX(5px); border-color: rgba(255,255,255,0.3); }
        
        @keyframes slideIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }

        .comment-header { display: flex; justify-content: space-between; margin-bottom: 5px; }
        .comment-user { font-weight: 600; font-size: 14px; color: var(--text-main); }
        .comment-time { font-size: 12px; color: var(--text-sub); }
        .comment-body { font-size: 14px; color: var(--text-sub); line-height: 1.5; }

        /* 弹幕浮层 (可选特效) */
        .danmaku-container {
            position: fixed; top: 100px; left: 0; width: 100%; height: 200px;
            pointer-events: none; z-index: 500; overflow: hidden;
            mask-image: linear-gradient(to bottom, transparent, black 20%, black 80%, transparent);
        }
        .danmaku-item {
            position: absolute; white-space: nowrap; color: var(--text-main); opacity: 0.6;
            font-size: 14px; padding: 5px 12px; border-radius: 20px;
            background: rgba(0,0,0,0.3); backdrop-filter: blur(4px);
            animation: floatLeft 10s linear infinite;
        }
        @keyframes floatLeft { from { transform: translateX(100vw); } to { transform: translateX(-100%); } }
    </style>
</head>
<body>
    <button class="theme-toggle" id="btnTheme" onclick="toggleTheme()" type="button" style="display:none;"></button>
    <canvas id="particle-canvas"></canvas>

    <form id="form1" runat="server">
    <asp:ScriptManager ID="ScriptManager1" runat="server"></asp:ScriptManager>

    <div class="navbar">
        <a href="#" class="brand">
            <i class="fas fa-atom"></i> SMART CAMPUS
        </a>
        <a href="javascript:history.back()" class="btn-back">
            <i class="fas fa-arrow-left"></i> 返回上一页
        </a>
    </div>

    <div class="danmaku-container" id="danmakuLayer"></div>

    <div class="container">
        <div class="course-header">
            <div class="course-title">
                <h1><asp:Label ID="lblCourseName" runat="server"></asp:Label></h1>
                <div class="course-info">
                    <span><i class="fas fa-chalkboard-teacher"></i> <asp:Label ID="lblTeacher" runat="server"></asp:Label></span>
                    <span><i class="fas fa-layer-group"></i> <asp:Label ID="lblCredit" runat="server"></asp:Label> 学分</span>
                    <span class="tag"><asp:Label ID="lblType" runat="server"></asp:Label></span>
                </div>
            </div>
            <div style="text-align:right;">
                <div style="font-size:32px; font-weight:700; color:var(--primary); font-family:'Rajdhani'">
                    <asp:Label ID="lblStudentCount" runat="server">0</asp:Label>
                </div>
                <div style="font-size:12px; color:var(--text-sub);">已选人数</div>
            </div>
        </div>

        <div class="discussion-area">
            <div class="section-title">
                <i class="far fa-comments"></i> 课程讨论与反馈
            </div>

            <asp:UpdatePanel ID="UpdatePanel1" runat="server">
                <ContentTemplate>
                    
                    <div class="input-panel">
                        <div class="avatar-box">ME</div>
                        <asp:TextBox ID="txtComment" runat="server" CssClass="comment-input" TextMode="MultiLine" placeholder="分享你的学习心得或提出问题..."></asp:TextBox>
                        <asp:Button ID="btnPost" runat="server" Text="发布留言" OnClick="btnPost_Click" CssClass="btn-post" />
                    </div>

                    <div class="comment-list">
                        <asp:Repeater ID="rptComments" runat="server">
                            <ItemTemplate>
                                <div class="comment-card">
                                    <div class="avatar-box" style="width:32px; height:32px; font-size:12px; background:rgba(255,255,255,0.1);">
                                        <i class="fas fa-user"></i>
                                    </div>
                                    <div style="flex:1;">
                                        <div class="comment-header">
                                            <span class="comment-user"><%# Eval("StudentName") %></span>
                                            <span class="comment-time"><%# Eval("PostTime", "{0:yyyy-MM-dd HH:mm}") %></span>
                                        </div>
                                        <div class="comment-body">
                                            <%# Eval("Content") %>
                                        </div>
                                    </div>
                                </div>
                            </ItemTemplate>
                        </asp:Repeater>
                        
                        <asp:Label ID="lblEmpty" runat="server" Visible="false" style="text-align:center; color:var(--text-sub); display:block; padding:20px;">
                            暂无留言，快来抢沙发吧！
                        </asp:Label>
                    </div>

                </ContentTemplate>
            </asp:UpdatePanel>
        </div>
    </div>
    </form>

    <script>
        // === 主题与背景 (保持一致性) ===
        const savedTheme = localStorage.getItem('theme') || 'dark';
        document.documentElement.setAttribute('data-theme', savedTheme);

        const canvas = document.getElementById('particle-canvas');
        const ctx = canvas.getContext('2d');
        let width, height, particles = [];

        function resize() { width = canvas.width = window.innerWidth; height = canvas.height = window.innerHeight; }
        
        class Particle {
            constructor() { this.reset(); }
            reset() {
                this.x = Math.random() * width; this.y = Math.random() * height;
                this.vy = (Math.random() - 0.5) * 0.5; this.r = Math.random() * 2; this.a = Math.random() * 0.5;
            }
            update() {
                this.y += this.vy; 
                if(this.y < 0 || this.y > height) this.reset();
            }
            draw() {
                ctx.beginPath(); ctx.arc(this.x, this.y, this.r, 0, Math.PI*2);
                ctx.fillStyle = `rgba(14, 165, 233, ${this.a})`; ctx.fill();
            }
        }

        function init() {
            resize();
            for(let i=0; i<50; i++) particles.push(new Particle());
            loop();
        }
        function loop() {
            ctx.clearRect(0,0,width,height);
            particles.forEach(p => { p.update(); p.draw(); });
            requestAnimationFrame(loop);
        }
        window.onresize = resize;
        init();

        // === 简单的弹幕模拟 (视觉效果) ===
        // 这里只是为了演示“创新点”，实际生产中应该从后端API获取
        const msgs = ["老师讲得很细致！", "下周的作业有点难...", "求组队做项目", "这门课给分好吗？", "打卡"];
        const layer = document.getElementById('danmakuLayer');
        
        function addDanmaku() {
            const el = document.createElement('div');
            el.className = 'danmaku-item';
            el.innerText = msgs[Math.floor(Math.random() * msgs.length)];
            el.style.top = Math.random() * 150 + 'px';
            el.style.animationDuration = (8 + Math.random() * 5) + 's';
            layer.appendChild(el);
            
            // 动画结束后移除
            setTimeout(() => { el.remove(); }, 15000);
        }
        
        // 每3秒生成一个模拟弹幕
        setInterval(addDanmaku, 3000);
    </script>
</body>
</html>