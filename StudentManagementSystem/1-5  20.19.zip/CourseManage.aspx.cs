﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Linq;

public partial class CourseDetail : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // 简单鉴权
        if (Session["User"] == null)
            Response.Redirect("Login.aspx");

        if (!IsPostBack)
        {
            if (Request.QueryString["cid"] != null)
            {
                string cid = Request.QueryString["cid"];
                LoadCourseInfo(cid);
                LoadComments(cid);
            }
            else
            {
                // 如果没有参数，跳回选课页 (实际部署建议更友好的错误页)
                Response.Redirect("CourseSelection.aspx");
            }
        }
    }

    private void LoadCourseInfo(string cid)
    {
        string sql = @"
            SELECT c.CourseName, c.Credit, c.CourseType, t.Name as TeacherName,
            (SELECT COUNT(*) FROM Scores WHERE CourseId = c.CourseId) as StuCount
            FROM Courses c
            LEFT JOIN Teachers t ON c.TeacherId = t.TeacherId
            WHERE c.CourseId = @cid";

        DataTable dt = SqlHelper.ExecuteQuery(sql, new SqlParameter("@cid", cid));
        if (dt.Rows.Count > 0)
        {
            DataRow dr = dt.Rows[0];
            lblCourseName.Text = dr["CourseName"].ToString();
            lblCredit.Text = dr["Credit"].ToString();
            lblType.Text = dr["CourseType"].ToString();
            lblTeacher.Text = dr["TeacherName"].ToString();
            lblStudentCount.Text = dr["StuCount"].ToString();
        }
    }

    private void LoadComments(string cid)
    {
        // 联表查询学生姓名
        string sql = @"
            SELECT cm.Content, cm.PostTime, s.Name as StudentName
            FROM CourseComments cm
            JOIN Students s ON cm.StudentId = s.StudentId
            WHERE cm.CourseId = @cid
            ORDER BY cm.PostTime DESC";

        DataTable dt = SqlHelper.ExecuteQuery(sql, new SqlParameter("@cid", cid));

        if (dt.Rows.Count > 0)
        {
            rptComments.DataSource = dt;
            rptComments.DataBind();
            lblEmpty.Visible = false;
        }
        else
        {
            rptComments.DataSource = null;
            rptComments.DataBind();
            lblEmpty.Visible = true;
        }
    }

    protected void btnPost_Click(object sender, EventArgs e)
    {
        string content = txtComment.Text.Trim();
        string cid = Request.QueryString["cid"];
        string uid = Session["UserId"] != null ? Session["UserId"].ToString() : "0";

        if (string.IsNullOrEmpty(content)) return;

        // 这里假设 UserId 对应 StudentId。如果是教师/管理员，逻辑需微调。
        // 为了演示稳健性，加个简单的角色判断或直接存
        if (Session["Role"] != null && Session["Role"].ToString() == "Student")
        {
            string sql = "INSERT INTO CourseComments (CourseId, StudentId, Content) VALUES (@cid, @uid, @txt)";

            SqlHelper.ExecuteNonQuery(sql,
                new SqlParameter("@cid", cid),
                new SqlParameter("@uid", uid),
                new SqlParameter("@txt", content));

            // 清空输入框并刷新
            txtComment.Text = "";
            LoadComments(cid);
        }
        else
        {
            // 非学生用户提示 (实际项目中可允许教师回复)
            ScriptManager.RegisterStartupScript(this, GetType(), "alert", "alert('仅限学生发表评论。');", true);
        }
    }
}