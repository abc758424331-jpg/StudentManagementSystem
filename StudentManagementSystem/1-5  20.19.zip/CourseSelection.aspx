﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="CourseSelection.aspx.cs" Inherits="CourseSelection" MaintainScrollPositionOnPostback="true" %>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" data-theme="dark">
<head runat="server">
    <title>选课中心 | 智慧教务中枢</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&family=Rajdhani:wght@500;700&display=swap" rel="stylesheet">
    
    <style>
        /* === 1. 核心主题变量 (与 StudentHome 保持一致) === */
        :root {
            --ease-elastic: cubic-bezier(0.68, -0.55, 0.265, 1.55);
            --ease-smooth: cubic-bezier(0.25, 0.46, 0.45, 0.94);
        }

        [data-theme="dark"] {
            --bg-color: #0b1120;
            --bg-gradient: radial-gradient(circle at 50% 50%, #1e293b 0%, #0b1120 100%);
            --glass-panel: rgba(30, 41, 59, 0.7);
            --glass-border: rgba(255, 255, 255, 0.1);
            --text-main: #f8fafc;
            --text-sub: #94a3b8;
            --primary: #06b6d4;
            --primary-shadow: rgba(6, 182, 212, 0.4);
            --accent: #8b5cf6;
            --success: #10b981;
            --danger: #ef4444;
            /* 粒子颜色 */
            --p-color-rgb: 6, 182, 212; 
            --l-color-rgb: 148, 163, 184;
            --table-hover: rgba(255, 255, 255, 0.05);
            --shadow-card: 0 10px 30px -10px rgba(0, 0, 0, 0.5);
        }

        [data-theme="light"] {
            --bg-color: #f1f5f9;
            --bg-gradient: linear-gradient(135deg, #e2e8f0 0%, #f8fafc 100%);
            --glass-panel: rgba(255, 255, 255, 0.8);
            --glass-border: rgba(255, 255, 255, 0.6);
            --text-main: #1e293b;
            --text-sub: #475569;
            --primary: #2563eb;
            --primary-shadow: rgba(37, 99, 235, 0.2);
            --accent: #7c3aed;
            --success: #059669;
            --danger: #dc2626;
            /* 粒子颜色 */
            --p-color-rgb: 37, 99, 235;
            --l-color-rgb: 148, 163, 184;
            --table-hover: rgba(37, 99, 235, 0.05);
            --shadow-card: 0 10px 30px -10px rgba(0, 0, 0, 0.1);
        }

        body {
            margin: 0; padding: 0;
            background: var(--bg-color); background-image: var(--bg-gradient);
            color: var(--text-main); font-family: 'Inter', sans-serif;
            overflow-x: hidden; min-height: 100vh;
            transition: background 0.6s ease, color 0.6s ease;
        }

        #particle-canvas {
            position: fixed; top: 0; left: 0; width: 100%; height: 100%;
            z-index: -1; pointer-events: none;
        }

        .fade-in { animation: fadeIn 0.8s var(--ease-smooth) forwards; opacity: 0; transform: translateY(20px); }
        @keyframes fadeIn { to { opacity: 1; transform: translateY(0); } }

        /* === 2. 导航栏 === */
        .navbar {
            height: 70px; padding: 0 40px;
            background: var(--glass-panel);
            backdrop-filter: blur(20px); -webkit-backdrop-filter: blur(20px);
            border-bottom: 1px solid var(--glass-border);
            display: flex; align-items: center; justify-content: space-between;
            position: fixed; top: 0; width: 100%; z-index: 1000; box-sizing: border-box;
        }

        .brand {
            font-family: 'Rajdhani', sans-serif; font-weight: 700; font-size: 24px;
            letter-spacing: 2px; color: var(--text-main);
            display: flex; align-items: center; gap: 10px; cursor: pointer;
            text-decoration: none;
        }
        .brand i { color: var(--primary); }

        .nav-actions { display: flex; align-items: center; gap: 20px; }

        .theme-toggle {
            width: 40px; height: 40px; border-radius: 50%;
            background: var(--glass-panel); border: 1px solid var(--glass-border);
            display: flex; align-items: center; justify-content: center;
            cursor: pointer; color: var(--text-main); font-size: 18px;
            transition: all 0.3s var(--ease-elastic);
        }
        .theme-toggle:hover { transform: rotate(180deg) scale(1.1); color: var(--primary); border-color: var(--primary); }

        .btn-back {
            background: transparent; border: 1px solid var(--glass-border); color: var(--text-sub);
            padding: 8px 20px; border-radius: 8px; cursor: pointer; transition: 0.3s;
            font-size: 13px; text-decoration: none; display: flex; align-items: center; gap: 8px;
        }
        .btn-back:hover { background: var(--glass-border); color: var(--text-main); }

        /* === 3. 选课主控台 === */
        .main-container { max-width: 1200px; margin: 110px auto 50px; padding: 0 20px; }

        .header-panel {
            display: flex; justify-content: space-between; align-items: flex-end;
            margin-bottom: 30px; padding-bottom: 20px;
            border-bottom: 1px solid var(--glass-border);
        }
        .page-title h2 { margin: 0; font-size: 28px; font-weight: 700; letter-spacing: -0.5px; }
        .page-title p { margin: 5px 0 0; color: var(--text-sub); font-size: 14px; }

        /* === 4. 赛博表格 === */
        .grid-container {
            background: var(--glass-panel); border: 1px solid var(--glass-border);
            border-radius: 16px; overflow: hidden; box-shadow: var(--shadow-card);
        }

        .cyber-grid { width: 100%; border-collapse: collapse; }
        .cyber-grid th {
            background: rgba(0,0,0,0.1); color: var(--text-sub);
            padding: 20px 25px; text-align: left; font-weight: 600; font-size: 12px;
            text-transform: uppercase; letter-spacing: 1px;
            border-bottom: 1px solid var(--glass-border);
        }
        .cyber-grid td {
            padding: 20px 25px; color: var(--text-main);
            border-bottom: 1px solid var(--glass-border);
            transition: 0.2s; font-size: 14px; vertical-align: middle;
        }
        .cyber-grid tr:hover td { background: var(--table-hover); }

        /* 课程名称高亮 */
        .course-name { font-weight: 700; font-size: 15px; color: var(--text-main); display: block; }
        .teacher-info { font-size: 12px; color: var(--text-sub); margin-top: 4px; display: block; }

        /* === 5. 霓虹容量条 (Neon Progress Bar) === */
        .capacity-box { width: 100%; max-width: 150px; }
        .capacity-text { font-family: 'Rajdhani', sans-serif; font-size: 14px; margin-bottom: 4px; display: flex; justify-content: space-between; }
        .capacity-text .curr { font-weight: 700; }
        .capacity-text .max { color: var(--text-sub); font-size: 12px; }
        
        .progress-track {
            height: 6px; background: rgba(255,255,255,0.1); border-radius: 3px; overflow: hidden;
        }
        .progress-fill {
            height: 100%; border-radius: 3px;
            background: var(--success);
            box-shadow: 0 0 10px var(--success);
            transition: width 0.5s ease;
        }
        .progress-fill.full { background: var(--danger); box-shadow: 0 0 10px var(--danger); }
        .progress-fill.warning { background: var(--accent); box-shadow: 0 0 10px var(--accent); }

        /* === 6. 按钮与状态 === */
        .btn-action {
            padding: 8px 24px; border-radius: 8px; font-size: 12px; font-weight: 600;
            cursor: pointer; transition: 0.3s; border: none; text-transform: uppercase;
            display: inline-flex; align-items: center; gap: 6px;
        }
        
        .btn-select {
            background: rgba(16, 185, 129, 0.1); color: var(--success); border: 1px solid var(--success);
        }
        .btn-select:hover { background: var(--success); color: #fff; box-shadow: 0 0 20px rgba(16, 185, 129, 0.4); }

        .btn-drop {
            background: rgba(239, 68, 68, 0.1); color: var(--danger); border: 1px solid var(--danger);
        }
        .btn-drop:hover { background: var(--danger); color: #fff; box-shadow: 0 0 20px rgba(239, 68, 68, 0.4); }

        .tag-full {
            padding: 6px 12px; border-radius: 6px; background: rgba(255,255,255,0.05);
            color: var(--text-sub); border: 1px solid var(--glass-border);
            font-size: 12px; cursor: not-allowed;
        }

        .status-badge {
            display: inline-flex; align-items: center; gap: 6px;
            padding: 6px 12px; border-radius: 20px;
            background: rgba(6, 182, 212, 0.1); color: var(--primary);
            border: 1px solid var(--primary); font-size: 12px; font-weight: 600;
        }

        /* 新增：评价按钮样式 */
        .btn-link-neon {
            color: var(--primary); text-decoration: none; font-size: 12px; font-weight: 600;
            display: inline-flex; align-items: center; gap: 5px; transition: 0.3s;
            padding: 5px 10px; border: 1px solid transparent; border-radius: 4px;
        }
        .btn-link-neon:hover { 
            border-color: var(--primary); background: rgba(6, 182, 212, 0.1); 
            box-shadow: 0 0 10px var(--primary-shadow); 
        }
    </style>
</head>
<body>
    <button class="theme-toggle" id="btnTheme" onclick="toggleTheme()" type="button" style="position:fixed; top:85px; right:40px; z-index:900;">
        <i class="fas fa-moon" id="themeIcon"></i>
    </button>

    <canvas id="particle-canvas"></canvas>

    <form id="form1" runat="server">
    <asp:ScriptManager ID="ScriptManager1" runat="server"></asp:ScriptManager>

    <div class="navbar fade-in">
        <a href="StudentHome.aspx" class="brand">
            <i class="fas fa-atom fa-spin" style="animation-duration: 10s;"></i> UNIVERSE 
            <span style="font-weight:300; opacity:0.6; font-size:14px; margin-left:5px;">COURSE HUB</span>
        </a>
        <div class="nav-actions">
            <a href="StudentHome.aspx" class="btn-back">
                <i class="fas fa-arrow-left"></i> Back to Dashboard
            </a>
            <asp:Button ID="btnLogout" runat="server" Text="LOGOUT" OnClick="btnLogout_Click" 
                CssClass="btn-back" style="color:var(--danger); border-color:var(--danger);" />
        </div>
    </div>

    <div class="main-container fade-in">
        
        <div class="header-panel">
            <div class="page-title">
                <h2>选课</h2>
                <p>Select your courses for the upcoming semester.</p>
            </div>
            <div style="text-align:right;">
                <span style="font-size:13px; color:var(--text-sub);">Current User:</span>
                <div style="font-weight:600; color:var(--primary); font-size:16px;">
                    <asp:Label ID="lblUser" runat="server"></asp:Label>
                </div>
            </div>
        </div>

        <asp:UpdatePanel ID="UpdatePanel1" runat="server">
            <ContentTemplate>
                
                <div class="grid-container">
                    <asp:GridView ID="gvAllCourses" runat="server" AutoGenerateColumns="False" 
                        DataKeyNames="CourseId" CssClass="cyber-grid" GridLines="None"
                        OnRowCommand="gvAllCourses_RowCommand">
                        <Columns>
                            <%-- 课程信息 --%>
                            <asp:TemplateField HeaderText="COURSE DETAILS">
                                <ItemTemplate>
                                    <span class="course-name"><%# Eval("CourseName") %></span>
                                    <span class="teacher-info">
                                        <i class="fas fa-chalkboard-teacher"></i> <%# Eval("TeacherInfo") %>
                                    </span>
                                </ItemTemplate>
                            </asp:TemplateField>

                            <%-- 学分 --%>
                            <asp:BoundField DataField="Credit" HeaderText="CREDIT" ItemStyle-HorizontalAlign="Center" ItemStyle-Font-Bold="true" />
                            
                            <%-- 容量条 --%>
                            <asp:TemplateField HeaderText="CAPACITY STATUS">
                                <ItemTemplate>
                                    <div class="capacity-box">
                                        <div class="capacity-text">
                                            <span class="curr" style='color:<%# Convert.ToInt32(Eval("CurrentCount")) >= Convert.ToInt32(Eval("MaxCapacity")) ? "var(--danger)" : "var(--success)" %>'>
                                                <%# Eval("CurrentCount") %>
                                            </span>
                                            <span class="max">/ <%# Eval("MaxCapacity") %></span>
                                        </div>
                                        <div class="progress-track">
                                            <div class='<%# "progress-fill " + (Convert.ToInt32(Eval("CurrentCount")) >= Convert.ToInt32(Eval("MaxCapacity")) ? "full" : (Convert.ToDouble(Eval("CurrentCount"))/Convert.ToDouble(Eval("MaxCapacity")) > 0.8 ? "warning" : "")) %>' 
                                                 style='<%# "width:" + (Math.Min(100, Convert.ToDouble(Eval("CurrentCount")) / Convert.ToDouble(Eval("MaxCapacity")) * 100)).ToString().Replace(",",".") + "%" %>'>
                                            </div>
                                        </div>
                                    </div>
                                </ItemTemplate>
                            </asp:TemplateField>

                            <%-- 选课状态 --%>
                            <asp:TemplateField HeaderText="STATUS" ItemStyle-HorizontalAlign="Center">
                                <ItemTemplate>
                                    <span class="status-badge" runat="server" visible='<%# Convert.ToBoolean(Eval("IsSelected")) %>'>
                                        <i class="fas fa-check"></i> ENROLLED
                                    </span>
                                </ItemTemplate>
                            </asp:TemplateField>

                            <%-- [新增] 课程评价/情报列 --%>
                            <asp:TemplateField HeaderText="INTEL" ItemStyle-HorizontalAlign="Center">
                                <ItemTemplate>
                                    <a href='CourseDetail.aspx?cid=<%# Eval("CourseId") %>' class="btn-link-neon">
                                        <i class="far fa-comments"></i> REVIEWS
                                    </a>
                                </ItemTemplate>
                            </asp:TemplateField>

                            <%-- 操作按钮 --%>
                            <asp:TemplateField HeaderText="ACTION" ItemStyle-Width="140px" ItemStyle-HorizontalAlign="Center">
                                <ItemTemplate>
                                    <%-- 退选 --%>
                                    <asp:Button ID="btnDrop" runat="server" Text="DROP" CommandName="DropCourse" 
                                        CommandArgument='<%# Eval("CourseId") %>' CssClass="btn-action btn-drop" 
                                        Visible='<%# Convert.ToBoolean(Eval("IsSelected")) %>' 
                                        OnClientClick="return confirm('Warning: You are about to drop this course.');" />

                                    <%-- 选课 --%>
                                    <asp:Button ID="btnSelect" runat="server" Text="ENROLL" CommandName="SelectCourse" 
                                        CommandArgument='<%# Eval("CourseId") %>' CssClass="btn-action btn-select" 
                                        Visible='<%# !Convert.ToBoolean(Eval("IsSelected")) && Convert.ToInt32(Eval("CurrentCount")) < Convert.ToInt32(Eval("MaxCapacity")) %>' />
                                    
                                    <%-- 已满 --%>
                                    <asp:Label ID="lblFull" runat="server" Text="FULL" CssClass="tag-full"
                                        Visible='<%# !Convert.ToBoolean(Eval("IsSelected")) && Convert.ToInt32(Eval("CurrentCount")) >= Convert.ToInt32(Eval("MaxCapacity")) %>'>
                                    </asp:Label>
                                </ItemTemplate>
                            </asp:TemplateField>
                        </Columns>
                        <EmptyDataTemplate>
                            <div style="padding:60px; text-align:center; color:var(--text-sub);">
                                <i class="fas fa-inbox" style="font-size:40px; margin-bottom:15px; opacity:0.5;"></i>
                                <p>No courses available for selection at this time.</p>
                            </div>
                        </EmptyDataTemplate>
                    </asp:GridView>
                </div>

            </ContentTemplate>
        </asp:UpdatePanel>

    </div>
    </form>

    <script>
        // === 主题引擎 ===
        const html = document.documentElement;
        const themeIcon = document.getElementById('themeIcon');
        const savedTheme = localStorage.getItem('theme') || 'dark';
        applyTheme(savedTheme);

        function toggleTheme() {
            const current = html.getAttribute('data-theme');
            const target = current === 'dark' ? 'light' : 'dark';
            document.body.style.transition = 'background 0.6s ease, color 0.6s ease';
            applyTheme(target);
            localStorage.setItem('theme', target);
        }

        function applyTheme(theme) {
            html.setAttribute('data-theme', theme);
            themeIcon.className = theme === 'dark' ? 'fas fa-moon' : 'fas fa-sun';
        }

        // === 粒子引擎 ===
        const canvas = document.getElementById('particle-canvas');
        const ctx = canvas.getContext('2d');
        let width, height;
        let particles = [];
        let mouse = { x: null, y: null };

        function getThemeColors() {
            const style = getComputedStyle(document.documentElement);
            const pColor = style.getPropertyValue('--p-color-rgb').trim().split(',');
            const lColor = style.getPropertyValue('--l-color-rgb').trim().split(',');
            return { p: pColor, l: lColor };
        }

        function resize() { width = canvas.width = window.innerWidth; height = canvas.height = window.innerHeight; }

        class Particle {
            constructor() {
                this.x = Math.random() * width; this.y = Math.random() * height;
                this.z = Math.random() * 1.5 + 0.5;
                this.vx = (Math.random() - 0.5) * 0.5 * this.z;
                this.vy = (Math.random() - 0.5) * 0.5 * this.z;
                this.size = Math.random() * 2 * this.z;
            }
            update() {
                this.x += this.vx; this.y += this.vy;
                if (mouse.x != null) {
                    let dx = mouse.x - this.x; let dy = mouse.y - this.y;
                    let distance = Math.sqrt(dx * dx + dy * dy);
                    if (distance < 250) {
                        const force = (250 - distance) / 250;
                        this.vx += (dx / distance) * force * 0.02 * this.z;
                        this.vy += (dy / distance) * force * 0.02 * this.z;
                    }
                }
                if (this.x < 0 || this.x > width) this.vx *= -1;
                if (this.y < 0 || this.y > height) this.vy *= -1;
            }
            draw(colors) {
                ctx.beginPath(); ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
                ctx.fillStyle = `rgba(${colors.p[0]}, ${colors.p[1]}, ${colors.p[2]}, ${0.5 * this.z})`; ctx.fill();
            }
        }

        function initParticles() { particles = []; for (let i = 0; i < 80; i++) particles.push(new Particle()); }

        function animate() {
            ctx.clearRect(0, 0, width, height); const colors = getThemeColors();
            for (let i = 0; i < particles.length; i++) {
                particles[i].update(); particles[i].draw(colors);
                for (let j = i + 1; j < particles.length; j++) {
                    let dx = particles[i].x - particles[j].x; let dy = particles[i].y - particles[j].y;
                    let distance = Math.sqrt(dx * dx + dy * dy);
                    if (distance < 100) {
                        ctx.beginPath();
                        let opacity = (1 - distance / 100) * 0.4 * particles[i].z;
                        ctx.strokeStyle = `rgba(${colors.l[0]}, ${colors.l[1]}, ${colors.l[2]}, ${opacity})`;
                        ctx.lineWidth = 0.5 * particles[i].z;
                        ctx.moveTo(particles[i].x, particles[i].y); ctx.lineTo(particles[j].x, particles[j].y); ctx.stroke();
                    }
                }
            }
            requestAnimationFrame(animate);
        }

        window.addEventListener('resize', () => { resize(); initParticles(); });
        window.addEventListener('mousemove', (e) => { mouse.x = e.x; mouse.y = e.y; });
        window.addEventListener('mouseout', () => { mouse.x = null; mouse.y = null; });
        resize(); initParticles(); animate();
    </script>
</body>
</html>