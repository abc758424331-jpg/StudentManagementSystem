﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

public partial class CourseSelection : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // 1. 权限验证
        if (Session["Role"] == null || Session["Role"].ToString() != "Student")
            Response.Redirect("Login.aspx");

        if (!IsPostBack)
        {
            // 显示当前用户信息
            lblUser.Text = Session["User"] != null ? Session["User"].ToString() : "Student";
            BindData();
        }
    }

    // --- 加载课程列表 ---
    private void BindData()
    {
        int stuId = Convert.ToInt32(Session["UserId"]);

        // 查询逻辑：
        // 1. IsSelected: 判断当前学生是否已选这门课 (用于前端显示 选课/退选 按钮)
        // 2. CurrentCount: 统计当前已选人数 (用于判断是否满员)
        string sql = @"
            SELECT 
                c.CourseId, 
                c.CourseName, 
                c.Credit, 
                c.MaxCapacity,
                (t.Name + ' (' + t.WorkNo + ')') as TeacherInfo,
                CASE WHEN s.ScoreId IS NOT NULL THEN 1 ELSE 0 END as IsSelected,
                (SELECT COUNT(1) FROM Scores WHERE CourseId = c.CourseId) as CurrentCount
            FROM Courses c
            LEFT JOIN Teachers t ON c.TeacherId = t.TeacherId
            LEFT JOIN Scores s ON c.CourseId = s.CourseId AND s.StudentId = @uid
            WHERE c.status = 1"; // 只显示状态为 1 (已发布) 的课程

        DataTable dt = SqlHelper.ExecuteQuery(sql, new SqlParameter("@uid", stuId));
        gvAllCourses.DataSource = dt;
        gvAllCourses.DataBind();
    }

    // --- 处理 选课 / 退选 操作 ---
    protected void gvAllCourses_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        int courseId = Convert.ToInt32(e.CommandArgument);
        int stuId = Convert.ToInt32(Session["UserId"]);

        // ========================================================
        // 1. 选课逻辑
        // ========================================================
        if (e.CommandName == "SelectCourse")
        {
            // 检查容量是否已满
            string sqlCheck = "SELECT MaxCapacity, (SELECT COUNT(*) FROM Scores WHERE CourseId=@cid) as Curr FROM Courses WHERE CourseId=@cid";
            DataTable dtCheck = SqlHelper.ExecuteQuery(sqlCheck, new SqlParameter("@cid", courseId));

            if (dtCheck.Rows.Count > 0)
            {
                int max = Convert.ToInt32(dtCheck.Rows[0]["MaxCapacity"]);
                int curr = Convert.ToInt32(dtCheck.Rows[0]["Curr"]);

                if (curr >= max)
                {
                    System.Web.UI.ScriptManager.RegisterStartupScript(this, GetType(), "alert", "alert('⚠️ System Alert: Course capacity reached limit.');", true);
                    BindData();
                    return;
                }
            }

            // 执行选课插入
            string currentTerm = "2024-2025-1"; // 默认当前学期
            string sqlInsert = "INSERT INTO Scores (StudentId, CourseId, Term, Score, RetakeStatus) VALUES (@sid, @cid, @term, 0, 0)";

            try
            {
                SqlHelper.ExecuteNonQuery(sqlInsert,
                    new SqlParameter("@sid", stuId),
                    new SqlParameter("@cid", courseId),
                    new SqlParameter("@term", currentTerm));

                System.Web.UI.ScriptManager.RegisterStartupScript(this, GetType(), "alert", "alert('✅ Course selected successfully!');", true);
            }
            catch (Exception ex)
            {
                System.Web.UI.ScriptManager.RegisterStartupScript(this, GetType(), "alert", "alert('Error: " + ex.Message + "');", true);
            }
        }
        // ========================================================
        // 2. 退选逻辑 (包含成绩检查)
        // ========================================================
        else if (e.CommandName == "DropCourse")
        {
            // [安全检查]：已有成绩 (>0) 的课程禁止退选
            string checkSql = "SELECT Score FROM Scores WHERE StudentId=@sid AND CourseId=@cid";
            object result = SqlHelper.ExecuteScalar(checkSql,
                new SqlParameter("@sid", stuId),
                new SqlParameter("@cid", courseId));

            double currentScore = 0;
            if (result != null && result != DBNull.Value)
            {
                double.TryParse(result.ToString(), out currentScore);
            }

            // 如果分数大于0，说明老师已经打分，禁止操作
            if (currentScore > 0)
            {
                string jsAlert = "alert('⛔ ACCESS DENIED: Cannot drop this course because grades have already been recorded.');";
                System.Web.UI.ScriptManager.RegisterStartupScript(this, GetType(), "alert", jsAlert, true);
                return; // 直接结束，不执行删除
            }

            // 只有没分数的课，才允许删除
            string sqlDelete = "DELETE FROM Scores WHERE StudentId=@sid AND CourseId=@cid";

            try
            {
                SqlHelper.ExecuteNonQuery(sqlDelete, new SqlParameter("@sid", stuId), new SqlParameter("@cid", courseId));

                // 提示成功
                System.Web.UI.ScriptManager.RegisterStartupScript(this, GetType(), "alert", "alert('✅ Course dropped successfully.');", true);
            }
            catch (Exception ex)
            {
                System.Web.UI.ScriptManager.RegisterStartupScript(this, GetType(), "alert", "alert('Error: " + ex.Message + "');", true);
            }
        }

        // 操作完成后刷新列表状态
        BindData();
    }

    // --- 注销 ---
    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session.Clear();
        Session.Abandon();
        Response.Redirect("Login.aspx");
    }
}