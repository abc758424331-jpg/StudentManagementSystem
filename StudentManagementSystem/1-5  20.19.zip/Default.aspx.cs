﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // 1. 权限验证
        if (Session["Role"] == null || Session["Role"].ToString() != "Admin")
            Response.Redirect("Login.aspx");

        if (!IsPostBack)
        {
            lblName.Text = Session["User"] != null ? Session["User"].ToString() : "Admin";
            LoadStats();
            BindStudents();
            BindTeachers();
        }
    }

    // --- 1. 加载 HUD 统计数据 ---
    private void LoadStats()
    {
        object stuCount = SqlHelper.ExecuteScalar("SELECT COUNT(*) FROM Students");
        ltlStudents.Text = stuCount.ToString();

        object teaCount = SqlHelper.ExecuteScalar("SELECT COUNT(*) FROM Teachers");
        ltlTeachers.Text = teaCount.ToString();

        // 统计活跃课程 (Status=1)
        object courseCount = SqlHelper.ExecuteScalar("SELECT COUNT(*) FROM Courses WHERE status=1");
        ltlCourses.Text = courseCount.ToString();
    }

    // --- 2. 绑定列表 ---
    private void BindStudents()
    {
        string sql = @"
            SELECT s.StudentId, s.StuNumber, s.Name, s.Phone, c.ClassName 
            FROM Students s 
            LEFT JOIN Classes c ON s.ClassId = c.ClassId 
            ORDER BY s.StuNumber ASC";

        DataTable dt = SqlHelper.ExecuteQuery(sql);
        gvStudents.DataSource = dt;
        gvStudents.DataBind();
    }

    private void BindTeachers()
    {
        string sql = "SELECT * FROM Teachers ORDER BY WorkNo ASC";
        DataTable dt = SqlHelper.ExecuteQuery(sql);
        gvTeachers.DataSource = dt;
        gvTeachers.DataBind();
    }

    // --- 3. 删除逻辑 (级联删除) ---
    protected void gvStudents_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "DelStudent")
        {
            int id = Convert.ToInt32(e.CommandArgument);

            // 级联删除：成绩 -> 评论 -> 学生
            SqlHelper.ExecuteNonQuery("DELETE FROM Scores WHERE StudentId=@id", new SqlParameter("@id", id));
            SqlHelper.ExecuteNonQuery("DELETE FROM CourseComments WHERE StudentId=@id", new SqlParameter("@id", id));
            SqlHelper.ExecuteNonQuery("DELETE FROM Students WHERE StudentId=@id", new SqlParameter("@id", id));

            BindStudents();
            LoadStats();
        }
    }

    protected void gvTeachers_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "DelTeacher")
        {
            int id = Convert.ToInt32(e.CommandArgument);

            // 级联删除：相关选课 -> 相关评论 -> 课程 -> 教师
            SqlHelper.ExecuteNonQuery(@"
                DELETE FROM Scores WHERE CourseId IN (SELECT CourseId FROM Courses WHERE TeacherId=@id)",
                new SqlParameter("@id", id));

            SqlHelper.ExecuteNonQuery(@"
                DELETE FROM CourseComments WHERE CourseId IN (SELECT CourseId FROM Courses WHERE TeacherId=@id)",
                new SqlParameter("@id", id));

            SqlHelper.ExecuteNonQuery("DELETE FROM Courses WHERE TeacherId=@id", new SqlParameter("@id", id));

            SqlHelper.ExecuteNonQuery("DELETE FROM Teachers WHERE TeacherId=@id", new SqlParameter("@id", id));

            BindTeachers();
            LoadStats();
        }
    }

    // --- 4. 分页 ---
    protected void gvStudents_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvStudents.PageIndex = e.NewPageIndex;
        BindStudents();
    }

    protected void gvTeachers_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvTeachers.PageIndex = e.NewPageIndex;
        BindTeachers();
    }

    // --- 5. 注销 ---
    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session.Clear();
        Session.Abandon();
        Response.Redirect("Login.aspx");
    }
}