﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            // 每次进入登录页，彻底清除会话，仿佛重启了系统连接
            Session.Clear();
            Session.Abandon();
        }
    }

    protected void btnLogin_Click(object sender, EventArgs e)
    {
        // 1. 获取输入 (去除首尾空格)
        string user = txtUser.Text.Trim();
        string pwd = txtPwd.Text.Trim();
        string role = "";

        // 2. 判定身份 (前端的滑块动画其实是控制这三个 RadioButton 的 Checked 状态)
        if (rbStudent.Checked) role = "Student";
        else if (rbTeacher.Checked) role = "Teacher";
        else if (rbAdmin.Checked) role = "Admin";

        // 3. 基础校验
        if (string.IsNullOrEmpty(user) || string.IsNullOrEmpty(pwd))
        {
            lblMsg.Text = "ACCESS DENIED: Credentials Required"; // 稍微有点极客风的提示
            return;
        }

        try
        {
            string sql = "";
            // 根据身份路由到不同的数据表
            if (role == "Admin")
            {
                sql = "SELECT * FROM Admins WHERE Username=@u AND Password=@p";
            }
            else if (role == "Teacher")
            {
                sql = "SELECT * FROM Teachers WHERE WorkNo=@u AND Password=@p";
            }
            else if (role == "Student")
            {
                sql = "SELECT * FROM Students WHERE StuNumber=@u AND Password=@p";
            }

            // 执行安全查询
            DataTable dt = SqlHelper.ExecuteQuery(sql, new SqlParameter("@u", user), new SqlParameter("@p", pwd));

            if (dt.Rows.Count > 0)
            {
                DataRow dr = dt.Rows[0];

                // 建立会话 (Session)
                Session["Role"] = role;

                if (role == "Admin")
                {
                    Session["User"] = "管理员";
                    Session["UserId"] = dr.Table.Columns.Contains("Id") ? dr["Id"].ToString() : "1";
                    Response.Redirect("Default.aspx");
                }
                else if (role == "Teacher")
                {
                    Session["User"] = dr["Name"].ToString();
                    Session["UserId"] = dr["TeacherId"].ToString();
                    Response.Redirect("TeacherHome.aspx");
                }
                else if (role == "Student")
                {
                    Session["User"] = dr["Name"].ToString();
                    Session["UserId"] = dr["StudentId"].ToString();
                    Session["UserNumber"] = dr["StuNumber"].ToString(); // 记录学号，后续要用
                    Response.Redirect("StudentHome.aspx");
                }
            }
            else
            {
                // 验证失败
                lblMsg.Text = "ACCESS DENIED: Invalid ID or Password";
            }
        }
        catch (Exception ex)
        {
            // 系统级错误
            lblMsg.Text = "SYSTEM ERROR: " + ex.Message;
        }
    }
}