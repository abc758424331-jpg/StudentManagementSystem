﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="ScoreManage.aspx.cs" Inherits="ScoreManage" MaintainScrollPositionOnPostback="true" %>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" data-theme="dark">
<head runat="server">
    <title>成绩录入 | 智慧教务中枢</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&family=Rajdhani:wght@500;700&display=swap" rel="stylesheet">
    
    <style>
        /* === 1. 核心主题变量 === */
        :root {
            --ease-elastic: cubic-bezier(0.68, -0.55, 0.265, 1.55);
            --ease-smooth: cubic-bezier(0.25, 0.46, 0.45, 0.94);
        }

        [data-theme="dark"] {
            --bg-color: #0b1120;
            --bg-gradient: radial-gradient(circle at 50% 50%, #1e293b 0%, #0b1120 100%);
            --glass-panel: rgba(30, 41, 59, 0.75);
            --glass-border: rgba(255, 255, 255, 0.1);
            --text-main: #f8fafc;
            --text-sub: #94a3b8;
            
            --primary: #06b6d4;
            --primary-shadow: rgba(6, 182, 212, 0.4);
            --accent: #f59e0b; /* 橙色用于输入焦点 */
            --success: #10b981;
            --danger: #ef4444;
            
            --p-color-rgb: 6, 182, 212; 
            --l-color-rgb: 148, 163, 184;
            --table-hover: rgba(255, 255, 255, 0.05);
            --shadow-card: 0 25px 50px -12px rgba(0, 0, 0, 0.6);
        }

        [data-theme="light"] {
            --bg-color: #f1f5f9;
            --bg-gradient: linear-gradient(135deg, #e2e8f0 0%, #f8fafc 100%);
            --glass-panel: rgba(255, 255, 255, 0.85);
            --glass-border: rgba(255, 255, 255, 0.6);
            --text-main: #1e293b;
            --text-sub: #475569;
            
            --primary: #2563eb; 
            --primary-shadow: rgba(37, 99, 235, 0.2);
            --accent: #d97706;
            --success: #059669;
            --danger: #dc2626;
            
            --p-color-rgb: 37, 99, 235;
            --l-color-rgb: 148, 163, 184;
            --table-hover: rgba(37, 99, 235, 0.05);
            --shadow-card: 0 20px 40px -10px rgba(0, 0, 0, 0.15);
        }

        body {
            margin: 0; padding: 0;
            background: var(--bg-color); background-image: var(--bg-gradient);
            color: var(--text-main); font-family: 'Inter', sans-serif;
            overflow-x: hidden; min-height: 100vh;
            transition: background 0.6s ease, color 0.6s ease;
        }

        #particle-canvas {
            position: fixed; top: 0; left: 0; width: 100%; height: 100%;
            z-index: -1; pointer-events: none;
        }

        .fade-in { animation: fadeIn 0.8s var(--ease-smooth) forwards; opacity: 0; transform: translateY(20px); }
        @keyframes fadeIn { to { opacity: 1; transform: translateY(0); } }

        /* === 2. 导航栏 === */
        .navbar {
            height: 70px; padding: 0 40px;
            background: var(--glass-panel);
            backdrop-filter: blur(20px); -webkit-backdrop-filter: blur(20px);
            border-bottom: 1px solid var(--glass-border);
            display: flex; align-items: center; justify-content: space-between;
            position: fixed; top: 0; width: 100%; z-index: 1000; box-sizing: border-box;
        }

        .brand {
            font-family: 'Rajdhani', sans-serif; font-weight: 700; font-size: 24px;
            letter-spacing: 2px; color: var(--text-main);
            display: flex; align-items: center; gap: 10px; text-decoration:none;
        }
        .brand i { color: var(--primary); }

        .nav-actions { display: flex; align-items: center; gap: 20px; }

        .theme-toggle {
            width: 40px; height: 40px; border-radius: 50%;
            background: var(--glass-panel); border: 1px solid var(--glass-border);
            display: flex; align-items: center; justify-content: center;
            cursor: pointer; color: var(--text-main); font-size: 18px;
            transition: all 0.3s var(--ease-elastic);
        }
        .theme-toggle:hover { transform: rotate(180deg) scale(1.1); color: var(--primary); border-color: var(--primary); }

        .btn-back {
            background: transparent; border: 1px solid var(--glass-border); color: var(--text-sub);
            padding: 8px 20px; border-radius: 8px; cursor: pointer; transition: 0.3s;
            font-size: 13px; text-decoration: none; display: flex; align-items: center; gap: 8px;
        }
        .btn-back:hover { background: var(--glass-border); color: var(--text-main); }

        .btn-logout {
            background: transparent; border: 1px solid var(--danger); color: var(--danger);
            padding: 6px 16px; border-radius: 6px; cursor: pointer; transition: 0.3s;
            font-size: 12px; letter-spacing: 1px; font-weight: 600;
        }
        .btn-logout:hover { background: var(--danger); color: #fff; box-shadow: 0 0 15px rgba(239, 68, 68, 0.4); }

        /* === 3. 录入控制台 === */
        .main-container { max-width: 1400px; margin: 110px auto 80px; padding: 0 20px; }

        .header-panel {
            display: flex; justify-content: space-between; align-items: flex-end;
            margin-bottom: 30px; padding-bottom: 20px; border-bottom: 1px solid var(--glass-border);
        }
        .course-title h2 { margin: 0; font-size: 28px; font-weight: 700; letter-spacing: 1px; }
        .course-title span { color: var(--primary); font-family: 'Rajdhani'; }
        .course-meta { color: var(--text-sub); font-size: 13px; margin-top: 5px; }

        /* 战术 HUD */
        .dashboard-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-bottom: 30px; }
        
        .hud-card {
            background: var(--glass-panel); border: 1px solid var(--glass-border);
            border-radius: 16px; padding: 20px; display: flex; align-items: center; gap: 20px;
            box-shadow: var(--shadow-card);
        }
        .hud-icon {
            width: 45px; height: 45px; border-radius: 12px; background: rgba(255,255,255,0.05);
            display: flex; align-items: center; justify-content: center; font-size: 20px; color: var(--text-sub);
        }
        .hud-info h4 { margin: 0; font-size: 11px; text-transform: uppercase; color: var(--text-sub); letter-spacing: 1px; }
        .hud-info .value { font-family: 'Rajdhani'; font-size: 28px; font-weight: 700; color: var(--text-main); }

        /* === 4. 全息录入表格 === */
        .grid-container {
            background: var(--glass-panel); border: 1px solid var(--glass-border);
            border-radius: 16px; overflow: hidden; box-shadow: var(--shadow-card);
        }

        .cyber-grid { width: 100%; border-collapse: collapse; }
        .cyber-grid th {
            background: rgba(0,0,0,0.1); color: var(--text-sub);
            padding: 15px 20px; text-align: left; font-weight: 600; font-size: 12px;
            text-transform: uppercase; letter-spacing: 1px;
            border-bottom: 1px solid var(--glass-border);
        }
        .cyber-grid td {
            padding: 10px 20px; color: var(--text-main);
            border-bottom: 1px solid var(--glass-border);
            transition: 0.2s; font-size: 14px; vertical-align: middle;
        }
        .cyber-grid tr:hover td { background: var(--table-hover); }

        /* 隐形输入框 (Stealth Input) */
        .stealth-input {
            background: transparent; border: none; border-bottom: 2px solid rgba(255,255,255,0.1);
            color: var(--text-main); font-family: 'Rajdhani', monospace; font-size: 16px; font-weight: 600;
            width: 60px; text-align: center; padding: 5px; transition: 0.3s;
        }
        .stealth-input:focus {
            border-bottom-color: var(--accent); outline: none; background: rgba(245, 158, 11, 0.05);
        }
        /* 总分列自动高亮 */
        .total-score { font-weight: 700; font-size: 18px; color: var(--primary); transition: 0.3s; }
        
        /* 底部操作栏 */
        .action-bar {
            position: fixed; bottom: 0; left: 0; width: 100%;
            background: var(--glass-panel); backdrop-filter: blur(20px);
            border-top: 1px solid var(--glass-border);
            padding: 15px 40px; box-sizing: border-box;
            display: flex; justify-content: flex-end; align-items: center; gap: 20px;
            z-index: 900; animation: slideUp 0.5s ease;
        }
        @keyframes slideUp { from { transform: translateY(100%); } to { transform: translateY(0); } }

        .btn-save {
            background: linear-gradient(135deg, var(--primary), var(--success));
            color: #fff; border: none; padding: 12px 30px; border-radius: 8px;
            font-weight: 700; font-size: 14px; letter-spacing: 1px; cursor: pointer;
            box-shadow: 0 5px 20px rgba(16, 185, 129, 0.3); transition: 0.3s;
        }
        .btn-save:hover { transform: translateY(-2px); box-shadow: 0 10px 30px rgba(16, 185, 129, 0.5); }

        /* 隐藏权重配置 (JS读取用) */
        .hidden-config { display: none; }
    </style>
</head>
<body>
    <button class="theme-toggle" id="btnTheme" onclick="toggleTheme()" type="button" style="position:fixed; top:85px; right:40px; z-index:900;">
        <i class="fas fa-moon" id="themeIcon"></i>
    </button>

    <canvas id="particle-canvas"></canvas>

    <form id="form1" runat="server">
    <asp:ScriptManager ID="ScriptManager1" runat="server"></asp:ScriptManager>

    <div class="navbar fade-in">
        <a href="TeacherHome.aspx" class="brand">
            <i class="fas fa-cube fa-spin" style="animation-duration: 10s;"></i> UNIVERSE 
            <span style="font-weight:300; opacity:0.6; font-size:14px; margin-left:5px;">TEACHER HUB</span>
        </a>
        <div class="nav-actions">
            <a href="TeacherHome.aspx" class="btn-back">
                <i class="fas fa-arrow-left"></i> Back to Dashboard
            </a>
            <asp:Button ID="btnLogout" runat="server" Text="LOGOUT" OnClick="btnLogout_Click" CssClass="btn-logout" />
        </div>
    </div>

    <div class="main-container">
        
        <div class="header-panel fade-in">
            <div class="course-title">
                <h2>GRADE CALIBRATION: <asp:Label ID="lblCourseName" runat="server"></asp:Label></h2>
                <div class="course-meta">
                    ID: <asp:Label ID="lblCourseId" runat="server"></asp:Label> &nbsp;|&nbsp; 
                    Semester: <asp:Label ID="lblTerm" runat="server"></asp:Label>
                </div>
            </div>
            <div style="text-align:right; font-size:12px; color:var(--text-sub);">
                WEIGHTS: 
                R:<asp:Label ID="lblWReg" runat="server" CssClass="weight-val">0</asp:Label>% 
                H:<asp:Label ID="lblWHwk" runat="server" CssClass="weight-val">0</asp:Label>% 
                M:<asp:Label ID="lblWMid" runat="server" CssClass="weight-val">0</asp:Label>% 
                F:<asp:Label ID="lblWFin" runat="server" CssClass="weight-val">0</asp:Label>%
            </div>
        </div>

        <div class="dashboard-grid fade-in" style="animation-delay: 0.1s;">
            <div class="hud-card">
                <div class="hud-icon" style="color:var(--primary);"><i class="fas fa-chart-line"></i></div>
                <div class="hud-info">
                    <h4>Class Average</h4>
                    <span class="value" id="hudAvg">0.0</span>
                </div>
            </div>
            <div class="hud-card">
                <div class="hud-info">
                    <h4>Pass Rate</h4>
                    <span class="value" id="hudPass" style="color:var(--success);">0%</span>
                </div>
                <div class="hud-icon" style="color:var(--success);"><i class="fas fa-check-circle"></i></div>
            </div>
            <div class="hud-card">
                <div class="hud-info">
                    <h4>Max Score</h4>
                    <span class="value" id="hudMax" style="color:var(--accent);">0</span>
                </div>
                <div class="hud-icon" style="color:var(--accent);"><i class="fas fa-trophy"></i></div>
            </div>
        </div>

        <asp:UpdatePanel ID="UpdatePanel1" runat="server">
            <ContentTemplate>
                
                <div class="grid-container fade-in" style="animation-delay: 0.2s;">
                    <asp:GridView ID="gvScores" runat="server" AutoGenerateColumns="False" 
                        DataKeyNames="ScoreId" CssClass="cyber-grid" GridLines="None">
                        <Columns>
                            <asp:BoundField DataField="StuNumber" HeaderText="STUDENT ID" ItemStyle-Font-Bold="true" />
                            <asp:BoundField DataField="Name" HeaderText="NAME" />
                            
                            <%-- 录入区域 --%>
                            <asp:TemplateField HeaderText="REGULAR">
                                <ItemTemplate>
                                    <asp:TextBox ID="txtReg" runat="server" Text='<%# Eval("ScoreRegular") %>' CssClass="stealth-input score-input reg" onkeyup="calcRow(this)"></asp:TextBox>
                                </ItemTemplate>
                            </asp:TemplateField>

                            <asp:TemplateField HeaderText="HOMEWORK">
                                <ItemTemplate>
                                    <asp:TextBox ID="txtHwk" runat="server" Text='<%# Eval("ScoreHomework") %>' CssClass="stealth-input score-input hwk" onkeyup="calcRow(this)"></asp:TextBox>
                                </ItemTemplate>
                            </asp:TemplateField>

                            <asp:TemplateField HeaderText="MIDTERM">
                                <ItemTemplate>
                                    <asp:TextBox ID="txtMid" runat="server" Text='<%# Eval("ScoreMidterm") %>' CssClass="stealth-input score-input mid" onkeyup="calcRow(this)"></asp:TextBox>
                                </ItemTemplate>
                            </asp:TemplateField>

                            <asp:TemplateField HeaderText="FINAL">
                                <ItemTemplate>
                                    <asp:TextBox ID="txtFin" runat="server" Text='<%# Eval("ScoreFinal") %>' CssClass="stealth-input score-input fin" onkeyup="calcRow(this)"></asp:TextBox>
                                </ItemTemplate>
                            </asp:TemplateField>

                            <%-- 自动计算总分 --%>
                            <asp:TemplateField HeaderText="TOTAL" ItemStyle-HorizontalAlign="Center">
                                <ItemTemplate>
                                    <span class="total-score val"><%# Eval("Score") %></span>
                                </ItemTemplate>
                            </asp:TemplateField>
                        </Columns>
                    </asp:GridView>
                </div>

                <div class="action-bar">
                    <span id="saveStatus" style="font-size:13px; color:var(--text-sub); margin-right:15px;"></span>
                    <asp:Button ID="btnSave" runat="server" Text="SAVE & CALCULATE" OnClick="btnSave_Click" CssClass="btn-save" />
                </div>

            </ContentTemplate>
        </asp:UpdatePanel>

    </div>
    </form>

    <script>
        // === 实时计算引擎 (Real-time Calc Engine) ===
        function calcRow(input) {
            const row = input.closest('tr');
            
            // 获取输入值 (默认为0)
            const reg = parseFloat(row.querySelector('.reg').value) || 0;
            const hwk = parseFloat(row.querySelector('.hwk').value) || 0;
            const mid = parseFloat(row.querySelector('.mid').value) || 0;
            const fin = parseFloat(row.querySelector('.fin').value) || 0;

            // 获取权重 (从页面顶部Label读取)
            const wReg = parseFloat(document.getElementById('<%= lblWReg.ClientID %>').innerText) / 100;
            const wHwk = parseFloat(document.getElementById('<%= lblWHwk.ClientID %>').innerText) / 100;
            const wMid = parseFloat(document.getElementById('<%= lblWMid.ClientID %>').innerText) / 100;
            const wFin = parseFloat(document.getElementById('<%= lblWFin.ClientID %>').innerText) / 100;

            // 计算总分
            let total = (reg * wReg) + (hwk * wHwk) + (mid * wMid) + (fin * wFin);
            total = Math.round(total * 10) / 10; // 保留1位小数

            // 更新显示
            const totalSpan = row.querySelector('.total-score');
            totalSpan.innerText = total;

            // 视觉反馈：不及格变红
            if(total < 60) totalSpan.style.color = 'var(--danger)';
            else totalSpan.style.color = 'var(--primary)';

            updateHUD();
        }

        // HUD 统计更新
        function updateHUD() {
            const totals = document.querySelectorAll('.total-score');
            let sum = 0, max = 0, passCount = 0;
            
            totals.forEach(el => {
                const val = parseFloat(el.innerText) || 0;
                sum += val;
                if(val > max) max = val;
                if(val >= 60) passCount++;
            });

            const count = totals.length;
            if(count > 0) {
                document.getElementById('hudAvg').innerText = (sum / count).toFixed(1);
                document.getElementById('hudPass').innerText = Math.round((passCount / count) * 100) + '%';
                document.getElementById('hudMax').innerText = max;
            }
        }

        // 初始化
        window.onload = function() {
            updateHUD();
            // 为所有行触发一次颜色检查
            document.querySelectorAll('.total-score').forEach(el => {
                if((parseFloat(el.innerText)||0) < 60) el.style.color = 'var(--danger)';
            });
        };
        var prm = Sys.WebForms.PageRequestManager.getInstance();
        prm.add_endRequest(function() { updateHUD(); });


        // === 主题与粒子引擎 (复用) ===
        const html = document.documentElement;
        const themeIcon = document.getElementById('themeIcon');
        const savedTheme = localStorage.getItem('theme') || 'dark';
        applyTheme(savedTheme);

        function toggleTheme() {
            const current = html.getAttribute('data-theme');
            const target = current === 'dark' ? 'light' : 'dark';
            document.body.style.transition = 'background 0.6s ease, color 0.6s ease';
            applyTheme(target);
            localStorage.setItem('theme', target);
        }

        function applyTheme(theme) {
            html.setAttribute('data-theme', theme);
            themeIcon.className = theme === 'dark' ? 'fas fa-moon' : 'fas fa-sun';
        }

        const canvas = document.getElementById('particle-canvas');
        const ctx = canvas.getContext('2d');
        let width, height, particles = [], mouse = { x: null, y: null };

        function getThemeColors() {
            const style = getComputedStyle(document.documentElement);
            const pColor = style.getPropertyValue('--p-color-rgb').trim().split(',');
            const lColor = style.getPropertyValue('--l-color-rgb').trim().split(',');
            return { p: pColor, l: lColor };
        }

        function resize() { width = canvas.width = window.innerWidth; height = canvas.height = window.innerHeight; }

        class Particle {
            constructor() {
                this.x = Math.random() * width; this.y = Math.random() * height;
                this.z = Math.random() * 1.5 + 0.5;
                this.vx = (Math.random() - 0.5) * 0.5 * this.z;
                this.vy = (Math.random() - 0.5) * 0.5 * this.z;
                this.size = Math.random() * 2 * this.z;
            }
            update() {
                this.x += this.vx; this.y += this.vy;
                if (this.x < 0 || this.x > width) this.vx *= -1;
                if (this.y < 0 || this.y > height) this.vy *= -1;
            }
            draw(colors) {
                ctx.beginPath(); ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
                ctx.fillStyle = `rgba(${colors.p[0]}, ${colors.p[1]}, ${colors.p[2]}, ${0.5 * this.z})`; ctx.fill();
            }
        }

        function initParticles() { particles = []; for (let i = 0; i < 80; i++) particles.push(new Particle()); }

        function animate() {
            ctx.clearRect(0, 0, width, height); const colors = getThemeColors();
            for (let i = 0; i < particles.length; i++) {
                particles[i].update(); particles[i].draw(colors);
                for (let j = i + 1; j < particles.length; j++) {
                    let dx = particles[i].x - particles[j].x; let dy = particles[i].y - particles[j].y;
                    let distance = Math.sqrt(dx*dx + dy*dy);
                    if (distance < 100) {
                        ctx.beginPath();
                        let opacity = (1 - distance/100) * 0.4 * particles[i].z;
                        ctx.strokeStyle = `rgba(${colors.l[0]}, ${colors.l[1]}, ${colors.l[2]}, ${opacity})`;
                        ctx.lineWidth = 0.5 * particles[i].z;
                        ctx.moveTo(particles[i].x, particles[i].y); ctx.lineTo(particles[j].x, particles[j].y); ctx.stroke();
                    }
                }
            }
            requestAnimationFrame(animate);
        }

        window.addEventListener('resize', () => { resize(); initParticles(); });
        resize(); initParticles(); animate();
    </script>
</body>
</html>