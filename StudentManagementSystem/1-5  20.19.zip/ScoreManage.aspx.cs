﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

public partial class ScoreManage : System.Web.UI.Page
{
    // 全局变量暂存权重，供Save使用
    protected double wReg = 0, wHwk = 0, wMid = 0, wFin = 0;

    protected void Page_Load(object sender, EventArgs e)
    {
        // 1. 权限验证
        if (Session["Role"] == null || Session["Role"].ToString() != "Teacher")
            Response.Redirect("Login.aspx");

        if (!IsPostBack)
        {
            if (Request.QueryString["cid"] != null)
            {
                string cid = Request.QueryString["cid"];
                // 处理可能为 null 的课程名
                string cname = Request.QueryString["cname"];
                if (cname == null) cname = "Unknown Course";

                lblCourseId.Text = cid;
                lblCourseName.Text = cname;

                // 加载数据
                LoadWeights(cid);
                LoadStudents(cid);
            }
        }
    }

    // --- 加载课程权重 ---
    private void LoadWeights(string cid)
    {
        string sql = "SELECT WeightRegular, WeightHomework, WeightMidterm, WeightFinal FROM Courses WHERE CourseId = @cid";
        DataTable dt = SqlHelper.ExecuteQuery(sql, new SqlParameter("@cid", cid));

        if (dt.Rows.Count > 0)
        {
            DataRow dr = dt.Rows[0];
            lblWReg.Text = dr["WeightRegular"].ToString();
            lblWHwk.Text = dr["WeightHomework"].ToString();
            lblWMid.Text = dr["WeightMidterm"].ToString();
            lblWFin.Text = dr["WeightFinal"].ToString();
        }
    }

    // --- 加载学生成绩列表 ---
    private void LoadStudents(string cid)
    {
        string sql = @"
            SELECT s.ScoreId, stu.StuNumber, stu.Name, 
                   s.ScoreRegular, s.ScoreHomework, s.ScoreMidterm, s.ScoreFinal, s.Score
            FROM Scores s
            JOIN Students stu ON s.StudentId = stu.StudentId
            WHERE s.CourseId = @cid ORDER BY stu.StuNumber";

        DataTable dt = SqlHelper.ExecuteQuery(sql, new SqlParameter("@cid", cid));
        gvScores.DataSource = dt;
        gvScores.DataBind();
    }

    // --- 保存并计算成绩 ---
    protected void btnSave_Click(object sender, EventArgs e)
    {
        string cid = lblCourseId.Text;

        // 1. 再次获取最新权重 (确保计算准确)
        LoadWeights(cid);
        double wr = Convert.ToDouble(lblWReg.Text) / 100.0;
        double wh = Convert.ToDouble(lblWHwk.Text) / 100.0;
        double wm = Convert.ToDouble(lblWMid.Text) / 100.0;
        double wf = Convert.ToDouble(lblWFin.Text) / 100.0;

        // 2. 遍历 GridView 保存数据
        foreach (GridViewRow row in gvScores.Rows)
        {
            int scoreId = Convert.ToInt32(gvScores.DataKeys[row.RowIndex].Value);

            // 获取输入框控件
            TextBox tReg = (TextBox)row.FindControl("txtReg");
            TextBox tHwk = (TextBox)row.FindControl("txtHwk");
            TextBox tMid = (TextBox)row.FindControl("txtMid");
            TextBox tFin = (TextBox)row.FindControl("txtFin");

            // 解析数值 (使用兼容旧版C#的辅助方法)
            double reg = ParseScore(tReg.Text);
            double hwk = ParseScore(tHwk.Text);
            double mid = ParseScore(tMid.Text);
            double fin = ParseScore(tFin.Text);

            // 服务器端计算总分 (防止前端篡改)
            double total = (reg * wr) + (hwk * wh) + (mid * wm) + (fin * wf);
            total = Math.Round(total, 1); // 保留1位小数

            // 更新数据库
            string sql = @"UPDATE Scores SET 
                           ScoreRegular=@r, ScoreHomework=@h, ScoreMidterm=@m, ScoreFinal=@f, Score=@t 
                           WHERE ScoreId=@id";

            SqlHelper.ExecuteNonQuery(sql,
                new SqlParameter("@r", reg),
                new SqlParameter("@h", hwk),
                new SqlParameter("@m", mid),
                new SqlParameter("@f", fin),
                new SqlParameter("@t", total),
                new SqlParameter("@id", scoreId));
        }

        // 3. 刷新显示 (让用户看到计算后的总分)
        LoadStudents(cid);

        // 4. 弹窗提示
        System.Web.UI.ScriptManager.RegisterStartupScript(this, GetType(), "alert", "alert('✅ Data Synchronized & Calculated!');", true);
    }

    // --- 辅助方法：安全解析分数 ---
    // [关键修复] 使用兼容 C# 5.0 的写法 (先声明变量)
    private double ParseScore(string text)
    {
        double val;
        if (double.TryParse(text, out val))
        {
            return val;
        }
        return 0; // 解析失败返回0
    }

    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session.Clear();
        Response.Redirect("Login.aspx");
    }
}