﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="StudentHome.aspx.cs" Inherits="StudentHome" MaintainScrollPositionOnPostback="true" %>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" data-theme="dark">
<head runat="server">
    <title>学生指挥中心 | 智慧教务中枢</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&family=Rajdhani:wght@500;700&display=swap" rel="stylesheet">
    
    <style>
        /* === 1. 核心主题变量 === */
        :root { --ease-out: cubic-bezier(0.25, 0.46, 0.45, 0.94); }
        [data-theme="dark"] {
            --bg-color: #0b1120;
            --bg-gradient: radial-gradient(circle at 50% 50%, #1e293b 0%, #0b1120 100%);
            --glass-panel: rgba(30, 41, 59, 0.7);
            --glass-border: rgba(255, 255, 255, 0.1);
            --text-main: #f8fafc;
            --text-sub: #94a3b8;
            --primary: #06b6d4; /* 科技蓝 */
            --accent: #8b5cf6;  /* 紫色 */
            --danger: #ef4444;  /* 警示红 */
            --success: #10b981;
            
            --p-color-rgb: 6, 182, 212; 
            --l-color-rgb: 148, 163, 184;
        }

        body {
            margin: 0; padding: 0;
            background: var(--bg-color); background-image: var(--bg-gradient);
            color: var(--text-main); font-family: 'Inter', sans-serif;
            overflow-x: hidden; min-height: 100vh;
        }

        #particle-canvas { position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: -1; pointer-events: none; }
        .fade-in { animation: fadeIn 0.8s var(--ease-out) forwards; opacity: 0; transform: translateY(20px); }
        @keyframes fadeIn { to { opacity: 1; transform: translateY(0); } }

        /* 导航栏 */
        .navbar {
            height: 70px; padding: 0 40px;
            background: var(--glass-panel); backdrop-filter: blur(20px);
            border-bottom: 1px solid var(--glass-border);
            display: flex; align-items: center; justify-content: space-between;
            position: fixed; top: 0; width: 100%; z-index: 1000; box-sizing: border-box;
        }
        .brand {
            font-family: 'Rajdhani', sans-serif; font-weight: 700; font-size: 24px;
            letter-spacing: 2px; color: var(--text-main); display: flex; align-items: center; gap: 10px; text-decoration: none;
        }
        .brand i { color: var(--primary); animation: spin 10s linear infinite; }
        @keyframes spin { 100% { transform: rotate(360deg); } }

        .btn-logout {
            background: transparent; border: 1px solid var(--danger); color: var(--danger);
            padding: 6px 16px; border-radius: 6px; cursor: pointer; transition: 0.3s;
            font-size: 12px; letter-spacing: 1px; font-weight: 600;
        }
        .btn-logout:hover { background: var(--danger); color: #fff; box-shadow: 0 0 15px rgba(239, 68, 68, 0.4); }

        /* 主界面 */
        .main-container { max-width: 1200px; margin: 110px auto 50px; padding: 0 20px; }

        .welcome-section { margin-bottom: 40px; }
        .welcome-section h1 { font-family: 'Rajdhani'; font-size: 42px; margin: 0; letter-spacing: 2px; }
        .welcome-section p { color: var(--text-sub); margin-top: 5px; font-size: 16px; }
        .user-highlight { color: var(--primary); font-weight: 700; }

        /* HUD 仪表盘 */
        .stats-grid {
            display: grid; grid-template-columns: repeat(3, 1fr); gap: 25px; margin-bottom: 40px;
        }
        .stat-card {
            background: var(--glass-panel); border: 1px solid var(--glass-border);
            border-radius: 20px; padding: 25px; position: relative; overflow: hidden;
            display: flex; align-items: center; justify-content: space-between;
            transition: transform 0.3s; box-shadow: 0 10px 30px -10px rgba(0,0,0,0.3);
        }
        .stat-card:hover { transform: translateY(-5px); border-color: var(--primary); }
        
        .stat-info h3 { margin: 0; font-size: 12px; color: var(--text-sub); text-transform: uppercase; letter-spacing: 1px; }
        .stat-info .value { font-family: 'Rajdhani'; font-size: 36px; font-weight: 700; color: var(--text-main); display: block; margin-top: 5px; }
        
        .ring-chart { width: 70px; height: 70px; position: relative; }
        .ring-bg { fill: none; stroke: rgba(255,255,255,0.1); stroke-width: 6; }
        .ring-fill { 
            fill: none; stroke: var(--primary); stroke-width: 6; stroke-linecap: round;
            transform: rotate(-90deg); transform-origin: 50% 50%;
            stroke-dasharray: 188; stroke-dashoffset: 188; transition: stroke-dashoffset 1.5s ease-out;
        }

        /* 快捷入口网格 */
        .action-grid {
            display: grid; grid-template-columns: repeat(2, 1fr); gap: 25px;
        }
        .action-card {
            background: var(--glass-panel); border: 1px solid var(--glass-border);
            border-radius: 16px; padding: 30px; text-decoration: none;
            display: flex; flex-direction: column; align-items: center; justify-content: center;
            transition: 0.3s; position: relative; height: 180px; overflow: hidden;
        }
        .action-card:hover { background: rgba(255,255,255,0.05); transform: scale(1.02); }
        
        .card-icon {
            width: 60px; height: 60px; border-radius: 16px; background: rgba(255,255,255,0.05);
            display: flex; align-items: center; justify-content: center; font-size: 28px; margin-bottom: 15px;
            transition: 0.3s;
        }
        .action-card:hover .card-icon { transform: scale(1.1); }
        
        .card-title { font-family: 'Rajdhani'; font-size: 20px; font-weight: 700; color: var(--text-main); letter-spacing: 1px; }
        .card-desc { font-size: 13px; color: var(--text-sub); margin-top: 5px; }

        /* 选课卡片 */
        .card-select { border-bottom: 4px solid var(--primary); }
        .card-select:hover .card-icon { background: var(--primary); color: #fff; box-shadow: 0 0 20px rgba(6, 182, 212, 0.4); }
        
        /* 成绩/补考卡片 (绿色，若有挂科会自动变红) */
        .card-grades { border-bottom: 4px solid var(--success); }
        .card-grades .card-icon { color: var(--success); }
        .card-grades .card-title { color: var(--success); }
        .card-grades:hover .card-icon { background: var(--success); color: #fff; box-shadow: 0 0 20px rgba(16, 185, 129, 0.4); }

        /* 挂科状态覆盖样式 (JS/后端控制) */
        .card-alert { border-bottom-color: var(--danger) !important; }
        .card-alert .card-icon { color: var(--danger) !important; animation: pulseRed 2s infinite; }
        .card-alert .card-title { color: var(--danger) !important; }
        .card-alert:hover .card-icon { background: var(--danger) !important; color: #fff; box-shadow: 0 0 25px rgba(239, 68, 68, 0.6) !important; }

        @keyframes pulseRed { 0% { box-shadow: 0 0 0 0 rgba(239, 68, 68, 0.4); } 70% { box-shadow: 0 0 0 10px rgba(239, 68, 68, 0); } 100% { box-shadow: 0 0 0 0 rgba(239, 68, 68, 0); } }

        /* 呼吸灯警报点 */
        .alert-dot {
            position: absolute; top: 20px; right: 20px; width: 12px; height: 12px;
            background: var(--danger); border-radius: 50%;
            box-shadow: 0 0 10px var(--danger); animation: blink 1.5s infinite;
        }
        @keyframes blink { 0% { opacity: 1; transform: scale(1); } 50% { opacity: 0.5; transform: scale(1.2); } 100% { opacity: 1; transform: scale(1); } }

    </style>
</head>
<body>
    <button class="theme-toggle" id="btnTheme" onclick="toggleTheme()" type="button" style="position:fixed; top:85px; right:40px; z-index:900; width:40px; height:40px; border-radius:50%; background:var(--glass-panel); border:1px solid var(--glass-border); color:var(--text-main); cursor:pointer;">
        <i class="fas fa-moon" id="themeIcon"></i>
    </button>

    <canvas id="particle-canvas"></canvas>

    <form id="form1" runat="server">
    
    <div class="navbar fade-in">
        <a href="#" class="brand">
            <i class="fas fa-cube"></i> UNIVERSE <span style="font-weight:300; opacity:0.6; font-size:14px; margin-left:5px;">STUDENT HUB</span>
        </a>
        <div style="display:flex; align-items:center; gap:20px;">
            <div style="text-align:right;">
                <div style="font-size:12px; color:var(--text-sub);">STUDENT ID</div>
                <div style="font-family:'Rajdhani'; font-weight:700; color:var(--primary);"><asp:Label ID="lblStuNo" runat="server"></asp:Label></div>
            </div>
            <asp:Button ID="btnLogout" runat="server" Text="LOGOUT" OnClick="btnLogout_Click" CssClass="btn-logout" />
        </div>
    </div>

    <div class="main-container fade-in">
        
        <div class="welcome-section">
            <h1>欢迎回来, <span class="user-highlight"><asp:Label ID="lblName" runat="server"></asp:Label></span></h1>
            <p>System Online. Academic synchronization complete.</p>
        </div>

        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-info">
                    <h3>Average Score</h3>
                    <span class="value"><asp:Literal ID="ltlAvgScore" runat="server">0.0</asp:Literal></span>
                </div>
                <div class="ring-chart">
                    <svg width="70" height="70">
                        <circle class="ring-bg" cx="35" cy="35" r="30"></circle>
                        <circle id="ringAvg" class="ring-fill" cx="35" cy="35" r="30" style="stroke:var(--primary)"></circle>
                    </svg>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-info">
                    <h3>Earned Credits</h3>
                    <span class="value"><asp:Literal ID="ltlCredits" runat="server">0</asp:Literal></span>
                </div>
                <div class="ring-chart">
                    <svg width="70" height="70">
                        <circle class="ring-bg" cx="35" cy="35" r="30"></circle>
                        <circle id="ringCredit" class="ring-fill" cx="35" cy="35" r="30" style="stroke:var(--success)"></circle>
                    </svg>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-info">
                    <h3>Failed Courses</h3>
                    <span class="value" style='color:<%= HasFailed ? "var(--danger)" : "var(--text-main)" %>'>
                        <asp:Literal ID="ltlFailed" runat="server">0</asp:Literal>
                    </span>
                </div>
                <div class="ring-chart">
                    <div style='width:100%; height:100%; display:flex; align-items:center; justify-content:center; font-size:24px; color:<%= HasFailed ? "var(--danger)" : "var(--text-sub)" %>'>
                        <i class="fas fa-exclamation-triangle"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="action-grid">
            
            <a href="CourseSelection.aspx" class="action-card card-select">
                <div class="card-icon">
                    <i class="fas fa-atom"></i>
                </div>
                <div class="card-title">COURSE SELECTION</div>
                <div class="card-desc">Browse catalog and enroll in new modules.</div>
            </a>

            <asp:Panel ID="pnlGradeCard" runat="server" CssClass="action-card card-grades">
                <a href="StudentScore.aspx" style="text-decoration:none; width:100%; height:100%; display:flex; flex-direction:column; align-items:center; justify-content:center;">
                    
                    <asp:Panel ID="pnlAlertDot" runat="server" Visible="false" CssClass="alert-dot"></asp:Panel>
                    
                    <div class="card-icon">
                        <i class="fas fa-chart-bar"></i>
                    </div>
                    <div class="card-title">MY GRADES & RETAKE</div>
                    <div class="card-desc">Check academic records and apply for retakes.</div>
                </a>
            </asp:Panel>

        </div>

    </div>
    </form>

    <script>
        // === 动画与交互 ===
        const html = document.documentElement;
        const themeIcon = document.getElementById('themeIcon');
        applyTheme('dark'); // 强制暗色

        function toggleTheme() {
            const current = html.getAttribute('data-theme');
            const target = current === 'dark' ? 'light' : 'dark';
            applyTheme(target);
        }
        function applyTheme(t) { html.setAttribute('data-theme', t); themeIcon.className = t === 'dark' ? 'fas fa-moon' : 'fas fa-sun'; }

        // HUD 环形进度条动画
        window.onload = function () {
            const avg = parseFloat(document.getElementById('<%= ltlAvgScore.ClientID %>').innerText) || 0;
            const credits = parseFloat(document.getElementById('<%= ltlCredits.ClientID %>').innerText) || 0;

            setProgress('ringAvg', avg / 100);
            setProgress('ringCredit', Math.min(credits / 50, 1)); // 假设满学分50
        };

        function setProgress(id, percent) {
            const circle = document.getElementById(id);
            if (circle) {
                const r = circle.r.baseVal.value;
                const c = r * 2 * Math.PI;
                circle.style.strokeDasharray = `${c} ${c}`;
                circle.style.strokeDashoffset = c;
                setTimeout(() => { circle.style.strokeDashoffset = c - percent * c; }, 500);
            }
        }

        // 粒子背景 (精简版)
        const canvas = document.getElementById('particle-canvas');
        const ctx = canvas.getContext('2d');
        let width, height, particles = [];
        function resize() { width = canvas.width = window.innerWidth; height = canvas.height = window.innerHeight; }
        class Particle {
            constructor() { this.x = Math.random() * width; this.y = Math.random() * height; this.vx = (Math.random() - .5); this.vy = (Math.random() - .5); this.size = Math.random() * 2; }
            update() { this.x += this.vx; this.y += this.vy; if (this.x < 0 || this.x > width) this.vx *= -1; if (this.y < 0 || this.y > height) this.vy *= -1; }
            draw() { ctx.beginPath(); ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2); ctx.fillStyle = 'rgba(6,182,212,0.5)'; ctx.fill(); }
        }
        function init() { particles = []; for (let i = 0; i < 50; i++) particles.push(new Particle()); }
        function animate() { ctx.clearRect(0, 0, width, height); particles.forEach(p => { p.update(); p.draw(); }); requestAnimationFrame(animate); }
        window.addEventListener('resize', () => { resize(); init(); }); resize(); init(); animate();
    </script>
</body>
</html>