﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;

public partial class StudentHome : System.Web.UI.Page
{
    // [修复] 去掉 "= false"，兼容旧版 C# 编译器
    // bool 类型默认就是 false，所以逻辑不受影响
    public bool HasFailed { get; set; }

    protected void Page_Load(object sender, EventArgs e)
    {
        // 1. 权限验证
        if (Session["Role"] == null || Session["Role"].ToString() != "Student")
            Response.Redirect("Login.aspx");

        if (!IsPostBack)
        {
            // 加载基本信息
            lblName.Text = Session["User"] != null ? Session["User"].ToString() : "Student";
            lblStuNo.Text = Session["UserNumber"] != null ? Session["UserNumber"].ToString() : "Unknown";

            LoadDashboardStats();
        }
    }

    private void LoadDashboardStats()
    {
        string uid = Session["UserId"].ToString();

        // 1. 计算平均分和已修学分 (只计算 >0 分的课程)
        string sqlStats = @"
            SELECT 
                ISNULL(AVG(s.Score), 0) as AvgScore,
                ISNULL(SUM(CASE WHEN s.Score >= 60 THEN c.Credit ELSE 0 END), 0) as TotalCredits
            FROM Scores s
            JOIN Courses c ON s.CourseId = c.CourseId
            WHERE s.StudentId = @uid AND s.Score > 0";

        DataTable dtStats = SqlHelper.ExecuteQuery(sqlStats, new SqlParameter("@uid", uid));
        if (dtStats.Rows.Count > 0)
        {
            double avg = Convert.ToDouble(dtStats.Rows[0]["AvgScore"]);
            double credits = Convert.ToDouble(dtStats.Rows[0]["TotalCredits"]);

            ltlAvgScore.Text = avg.ToString("F1");
            ltlCredits.Text = credits.ToString("F1");
        }

        // 2. 统计挂科数
        string sqlFail = "SELECT COUNT(*) FROM Scores WHERE StudentId = @uid AND Score < 60 AND Score > 0";
        object failResult = SqlHelper.ExecuteScalar(sqlFail, new SqlParameter("@uid", uid));
        int failCount = Convert.ToInt32(failResult);

        ltlFailed.Text = failCount.ToString();

        // 标记是否有挂科 (前端变红逻辑)
        if (failCount > 0)
        {
            HasFailed = true;
        }
        else
        {
            HasFailed = false;
        }

        // 3. 检查是否有“需重修”状态 (RetakeStatus = 1 表示挂科未处理)
        string sqlAlert = "SELECT COUNT(*) FROM Scores WHERE StudentId = @uid AND RetakeStatus = 1";
        int alertCount = Convert.ToInt32(SqlHelper.ExecuteScalar(sqlAlert, new SqlParameter("@uid", uid)));

        // 如果有未处理的挂科：
        // (1) 显示红点
        pnlAlertDot.Visible = (alertCount > 0);

        // (2) 改变卡片样式为红色警报
        if (alertCount > 0)
        {
            pnlGradeCard.CssClass += " card-alert";
        }
    }

    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session.Clear();
        Response.Redirect("Login.aspx");
    }
}