﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

public partial class StudentScore : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // 鉴权
        if (Session["Role"] == null || Session["Role"].ToString() != "Student")
            Response.Redirect("Login.aspx");

        if (!IsPostBack)
        {
            LoadTerms();
            BindData();
        }
    }

    // 1. 加载学期下拉框
    private void LoadTerms()
    {
        string uid = Session["UserId"].ToString();
        // 查找该学生所有有成绩的学期
        string sql = "SELECT DISTINCT Term FROM Scores WHERE StudentId = @uid ORDER BY Term DESC";
        DataTable dt = SqlHelper.ExecuteQuery(sql, new SqlParameter("@uid", uid));

        ddlTerm.DataSource = dt;
        ddlTerm.DataTextField = "Term";
        ddlTerm.DataValueField = "Term";
        ddlTerm.DataBind();

        // 默认选中第一个(最新学期)，如果没有数据则不添加
        if (ddlTerm.Items.Count == 0)
        {
            ddlTerm.Items.Insert(0, new ListItem("No Records", "0"));
        }
    }

    // 2. 加载成绩列表
    private void BindData()
    {
        string uid = Session["UserId"].ToString();
        string term = ddlTerm.SelectedValue;

        string sql = @"
            SELECT 
                s.ScoreId, s.Score, s.Term, s.RetakeStatus,
                s.ScoreRegular, s.ScoreMidterm, s.ScoreFinal,
                c.CourseName, c.Credit, c.CourseType,
                t.Name as TeacherName
            FROM Scores s
            JOIN Courses c ON s.CourseId = c.CourseId
            LEFT JOIN Teachers t ON c.TeacherId = t.TeacherId
            WHERE s.StudentId = @uid AND s.Term = @term";

        DataTable dt = SqlHelper.ExecuteQuery(sql,
            new SqlParameter("@uid", uid),
            new SqlParameter("@term", term));

        gvScores.DataSource = dt;
        gvScores.DataBind();

        // 计算当前学期的简单统计
        CalculateTermStats(dt);
    }

    private void CalculateTermStats(DataTable dt)
    {
        if (dt.Rows.Count == 0) return;

        double totalScore = 0;
        double totalCredit = 0;
        int count = 0;

        foreach (DataRow dr in dt.Rows)
        {
            double score = Convert.ToDouble(dr["Score"]);
            // 只有 > 0 的才算
            if (score > 0)
            {
                totalScore += score;
                count++;
                // 只有及格才算学分
                if (score >= 60)
                    totalCredit += Convert.ToDouble(dr["Credit"]);
            }
        }

        if (count > 0)
            ltlTermAvg.Text = (totalScore / count).ToString("F1");
        else
            ltlTermAvg.Text = "0.0";

        ltlTermCredit.Text = totalCredit.ToString("F1");
    }

    // 3. 学期筛选改变
    protected void ddlTerm_SelectedIndexChanged(object sender, EventArgs e)
    {
        BindData();
    }

    // 4. 处理重修申请
    protected void gvScores_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "ApplyRetake")
        {
            int scoreId = Convert.ToInt32(e.CommandArgument);

            // 更新状态为 2 (已申请)
            string sql = "UPDATE Scores SET RetakeStatus = 2 WHERE ScoreId = @id";

            try
            {
                SqlHelper.ExecuteNonQuery(sql, new SqlParameter("@id", scoreId));

                BindData(); // 刷新界面，按钮应该会变成 "PENDING"

                System.Web.UI.ScriptManager.RegisterStartupScript(this, GetType(), "alert", "alert('✅ Retake application submitted successfully!');", true);
            }
            catch (Exception ex)
            {
                System.Web.UI.ScriptManager.RegisterStartupScript(this, GetType(), "alert", "alert('❌ Error: " + ex.Message + "');", true);
            }
        }
    }
}