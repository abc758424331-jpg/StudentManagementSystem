﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class TeacherHome : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // 1. 权限验证
        if (Session["Role"] == null || Session["Role"].ToString() != "Teacher")
            Response.Redirect("Login.aspx");

        if (!IsPostBack)
        {
            lblName.Text = Session["User"] != null ? Session["User"].ToString() : "Teacher";

            LoadTerms();      // <--- 这里修改了逻辑
            LoadMyCourses();  // 加载课程

            // 2. 检查是否有待审批的补考，触发HUD警报
            CheckTodo();
        }
    }

    // [核心修复] 加载学期下拉框
    private void LoadTerms()
    {
        // 旧逻辑：只查 Scores 表 -> 导致新课学期不显示
        // 新逻辑：同时查 Courses 表和 Scores 表，获取所有相关学期
        string sql = @"
            SELECT semester AS Term FROM Courses WHERE semester IS NOT NULL
            UNION
            SELECT Term FROM Scores WHERE Term IS NOT NULL
            ORDER BY Term DESC";

        DataTable dt = SqlHelper.ExecuteQuery(sql);

        ddlTerm.DataSource = dt;
        ddlTerm.DataTextField = "Term";
        ddlTerm.DataValueField = "Term";
        ddlTerm.DataBind();

        // 如果下拉框是空的（比如完全没数据），给一个默认值
        if (ddlTerm.Items.Count == 0)
        {
            ddlTerm.Items.Add(new ListItem("2025-2026-1")); // 默认显示下学期
        }
    }

    private void LoadMyCourses()
    {
        int tid = Convert.ToInt32(Session["UserId"]);
        string term = ddlTerm.SelectedValue; // 现在这里能取到新学期了

        // 查询当前老师、当前学期的所有课程 (包括审核中的)
        string sql = "SELECT * FROM Courses WHERE TeacherId = @tid AND semester = @term ORDER BY CourseId DESC";

        DataTable dt = SqlHelper.ExecuteQuery(sql,
            new SqlParameter("@tid", tid),
            new SqlParameter("@term", term));

        gvMyCourses.DataSource = dt;
        gvMyCourses.DataBind();

        // 更新统计数据
        ltlCourseCount.Text = dt.Rows.Count.ToString();

        // 统计该学期该老师的学生总人次
        string sqlStu = @"
            SELECT COUNT(*) 
            FROM Scores s 
            JOIN Courses c ON s.CourseId = c.CourseId 
            WHERE c.TeacherId = @tid AND c.semester = @term";

        object stuRes = SqlHelper.ExecuteScalar(sqlStu,
            new SqlParameter("@tid", tid),
            new SqlParameter("@term", term));

        ltlStudentCount.Text = stuRes != null ? stuRes.ToString() : "0";
    }

    // 状态显示辅助方法
    public string GetStatusHtml(object statusObj)
    {
        int status = Convert.ToInt32(statusObj);
        if (status == 1)
        {
            return "<span class='badge badge-active'><i class='fas fa-check-circle'></i> ACTIVE</span>";
        }
        else
        {
            return "<span class='badge badge-pending'><i class='fas fa-hourglass-half'></i> PENDING</span>";
        }
    }

    // 检查待办事项
    private void CheckTodo()
    {
        int tid = Convert.ToInt32(Session["UserId"]);
        // 检查是否有补考申请 (RetakeStatus=2)
        string sql = @"
            SELECT COUNT(*) 
            FROM Scores s
            JOIN Courses c ON s.CourseId = c.CourseId
            WHERE s.RetakeStatus = 2 
              AND c.TeacherId = @tid";

        object result = SqlHelper.ExecuteScalar(sql, new SqlParameter("@tid", tid));
        int count = Convert.ToInt32(result == DBNull.Value ? 0 : result);

        ltlTodoCount.Text = count.ToString();

        // 警报样式
        if (count > 0)
        {
            if (!pnlTodo.CssClass.Contains("card-alert"))
                pnlTodo.CssClass += " card-alert";
        }
        else
        {
            pnlTodo.CssClass = pnlTodo.CssClass.Replace(" card-alert", "").Trim();
        }
    }

    protected void ddlTerm_SelectedIndexChanged(object sender, EventArgs e)
    {
        LoadMyCourses();
    }

    protected void gvMyCourses_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Config")
        {
            string cid = e.CommandArgument.ToString();
            Response.Redirect("CourseConfig.aspx?cid=" + cid);
        }
        else if (e.CommandName == "Grade")
        {
            GridViewRow row = (GridViewRow)((Control)e.CommandSource).NamingContainer;
            string cname = row.Cells[0].Text;
            string cid = e.CommandArgument.ToString();
            Response.Redirect("TeacherGrade.aspx?cid=" + cid + "&cname=" + Server.UrlEncode(cname));
        }
    }

    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session.Clear();
        Session.Abandon();
        Response.Redirect("Login.aspx");
    }
}