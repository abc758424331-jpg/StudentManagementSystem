﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="TeacherList.aspx.cs" Inherits="TeacherList" MaintainScrollPositionOnPostback="true" %>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" data-theme="dark">
<head runat="server">
    <title>教师名录 | 智慧教务中枢</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&family=Rajdhani:wght@500;700&display=swap" rel="stylesheet">
    
    <style>
        /* === 1. 核心主题变量 (管理员版 - 绿色/青色系) === */
        :root {
            --ease-elastic: cubic-bezier(0.68, -0.55, 0.265, 1.55);
            --ease-smooth: cubic-bezier(0.25, 0.46, 0.45, 0.94);
        }

        [data-theme="dark"] {
            --bg-color: #0b1120;
            --bg-gradient: radial-gradient(circle at 50% 50%, #1e293b 0%, #0b1120 100%);
            --glass-panel: rgba(30, 41, 59, 0.75);
            --glass-border: rgba(255, 255, 255, 0.1);
            --text-main: #f8fafc;
            --text-sub: #94a3b8;
            
            --primary: #10b981; /* 信号绿 */
            --primary-shadow: rgba(16, 185, 129, 0.4);
            --accent: #3b82f6;
            --danger: #ef4444;
            
            --p-color-rgb: 16, 185, 129; 
            --l-color-rgb: 148, 163, 184;
            --input-bg: rgba(15, 23, 42, 0.6);
            --table-hover: rgba(255, 255, 255, 0.05);
            --shadow-card: 0 25px 50px -12px rgba(0, 0, 0, 0.6);
        }

        [data-theme="light"] {
            --bg-color: #f1f5f9;
            --bg-gradient: linear-gradient(135deg, #e2e8f0 0%, #f8fafc 100%);
            --glass-panel: rgba(255, 255, 255, 0.85);
            --glass-border: rgba(255, 255, 255, 0.6);
            --text-main: #1e293b;
            --text-sub: #475569;
            
            --primary: #059669; 
            --primary-shadow: rgba(5, 150, 105, 0.2);
            --accent: #2563eb;
            --danger: #dc2626;
            
            --p-color-rgb: 5, 150, 105;
            --l-color-rgb: 148, 163, 184;
            --input-bg: rgba(255, 255, 255, 0.8);
            --table-hover: rgba(37, 99, 235, 0.05);
            --shadow-card: 0 20px 40px -10px rgba(0, 0, 0, 0.15);
        }

        body {
            margin: 0; padding: 0;
            background: var(--bg-color); background-image: var(--bg-gradient);
            color: var(--text-main); font-family: 'Inter', sans-serif;
            overflow-x: hidden; min-height: 100vh;
            transition: background 0.6s ease, color 0.6s ease;
        }

        #particle-canvas {
            position: fixed; top: 0; left: 0; width: 100%; height: 100%;
            z-index: -1; pointer-events: none;
        }

        .fade-in { animation: fadeIn 0.8s var(--ease-smooth) forwards; opacity: 0; transform: translateY(20px); }
        @keyframes fadeIn { to { opacity: 1; transform: translateY(0); } }

        /* === 2. 导航栏 === */
        .navbar {
            height: 70px; padding: 0 40px;
            background: var(--glass-panel);
            backdrop-filter: blur(20px); -webkit-backdrop-filter: blur(20px);
            border-bottom: 1px solid var(--glass-border);
            display: flex; align-items: center; justify-content: space-between;
            position: fixed; top: 0; width: 100%; z-index: 1000; box-sizing: border-box;
        }

        .brand {
            font-family: 'Rajdhani', sans-serif; font-weight: 700; font-size: 24px;
            letter-spacing: 2px; color: var(--text-main);
            display: flex; align-items: center; gap: 10px; text-decoration:none;
        }
        .brand i { color: var(--primary); }

        .nav-actions { display: flex; align-items: center; gap: 20px; }

        .theme-toggle {
            width: 40px; height: 40px; border-radius: 50%;
            background: var(--glass-panel); border: 1px solid var(--glass-border);
            display: flex; align-items: center; justify-content: center;
            cursor: pointer; color: var(--text-main); font-size: 18px;
            transition: all 0.3s var(--ease-elastic);
        }
        .theme-toggle:hover { transform: rotate(180deg) scale(1.1); color: var(--primary); border-color: var(--primary); }

        .btn-back {
            background: transparent; border: 1px solid var(--glass-border); color: var(--text-sub);
            padding: 8px 20px; border-radius: 8px; cursor: pointer; transition: 0.3s;
            font-size: 13px; text-decoration: none; display: flex; align-items: center; gap: 8px;
        }
        .btn-back:hover { background: var(--glass-border); color: var(--text-main); }

        .user-profile {
            display: flex; align-items: center; gap: 12px;
            padding: 6px 16px; border-radius: 30px;
            background: rgba(125,125,125,0.1); border: 1px solid var(--glass-border);
        }
        .user-avatar {
            width: 32px; height: 32px; border-radius: 50%;
            background: linear-gradient(135deg, var(--primary), var(--accent));
            display: flex; align-items: center; justify-content: center;
            font-weight: 700; color: #fff; font-size: 14px;
        }

        .btn-logout {
            background: transparent; border: 1px solid var(--danger); color: var(--danger);
            padding: 6px 16px; border-radius: 6px; cursor: pointer; transition: 0.3s;
            font-size: 12px; letter-spacing: 1px; font-weight: 600;
        }
        .btn-logout:hover { background: var(--danger); color: #fff; box-shadow: 0 0 15px rgba(239, 68, 68, 0.4); }

        /* === 3. 列表主控台 === */
        .main-container { max-width: 1200px; margin: 110px auto 50px; padding: 0 20px; }

        /* 搜索雷达栏 */
        .search-bar-container {
            display: flex; justify-content: space-between; align-items: center;
            background: var(--glass-panel); border: 1px solid var(--glass-border);
            border-radius: 16px; padding: 20px; margin-bottom: 25px;
            box-shadow: var(--shadow-card);
        }
        .search-group { display: flex; align-items: center; gap: 15px; flex: 1; max-width: 600px; position: relative; }
        
        .cyber-search {
            width: 100%; padding: 12px 15px 12px 45px;
            background: var(--input-bg); border: 1px solid var(--glass-border);
            border-radius: 10px; color: var(--text-main); font-size: 14px;
            box-sizing: border-box; transition: all 0.3s ease;
        }
        .cyber-search:focus {
            border-color: var(--primary); outline: none;
            box-shadow: 0 0 0 4px var(--primary-shadow);
        }
        .search-icon {
            position: absolute; left: 15px; color: var(--text-sub); pointer-events: none;
        }
        .cyber-search:focus + .search-icon { color: var(--primary); }

        .btn-neon {
            background: rgba(16, 185, 129, 0.1); border: 1px solid var(--primary); color: var(--primary);
            padding: 10px 25px; border-radius: 8px; cursor: pointer; transition: 0.3s;
            font-weight: 600; font-size: 13px; text-transform: uppercase;
            display: inline-flex; align-items: center; gap: 8px;
        }
        .btn-neon:hover { background: var(--primary); color: #fff; box-shadow: 0 0 20px var(--primary-shadow); }

        /* 统计胶囊 */
        .stats-capsule {
            display: flex; gap: 20px;
            font-family: 'Rajdhani', sans-serif; color: var(--text-sub); font-size: 14px;
        }
        .stats-capsule span { color: var(--text-main); font-weight: 700; font-size: 18px; margin-left: 5px; }

        /* === 4. 数据表格 === */
        .grid-container {
            background: var(--glass-panel); border: 1px solid var(--glass-border);
            border-radius: 16px; overflow: hidden; box-shadow: var(--shadow-card);
        }

        .cyber-grid { width: 100%; border-collapse: collapse; }
        .cyber-grid th {
            background: rgba(0,0,0,0.1); color: var(--text-sub);
            padding: 18px 25px; text-align: left; font-weight: 600; font-size: 12px;
            text-transform: uppercase; letter-spacing: 1px;
            border-bottom: 1px solid var(--glass-border);
        }
        .cyber-grid td {
            padding: 15px 25px; color: var(--text-main);
            border-bottom: 1px solid var(--glass-border);
            transition: 0.2s; font-size: 14px; vertical-align: middle;
        }
        .cyber-grid tr:hover td { background: var(--table-hover); }

        /* ID 标签 */
        .id-badge {
            font-family: 'Rajdhani', monospace; font-weight: 700; color: var(--accent);
            background: rgba(59, 130, 246, 0.1); padding: 4px 10px; border-radius: 6px;
            border: 1px solid rgba(59, 130, 246, 0.2); letter-spacing: 1px;
        }

        /* 操作按钮 */
        .action-btn {
            width: 32px; height: 32px; border-radius: 8px; border: 1px solid var(--glass-border);
            background: rgba(255,255,255,0.05); color: var(--text-sub);
            display: flex; align-items: center; justify-content: center; cursor: pointer; transition: 0.2s;
            text-decoration: none;
        }
        .action-btn:hover { transform: translateY(-2px); color: #fff; }
        .action-btn.del:hover { background: var(--danger); border-color: var(--danger); box-shadow: 0 0 10px rgba(239, 68, 68, 0.4); }
        .action-btn.edit:hover { background: var(--accent); border-color: var(--accent); box-shadow: 0 0 10px rgba(59, 130, 246, 0.4); }

        /* 分页样式 */
        .pager-row { background: rgba(0,0,0,0.1); padding: 15px; display: flex; justify-content: flex-end; }
        .pager-row table { border-collapse: separate; border-spacing: 5px; }
        .pager-row td { padding: 0; border: none; }
        .pager-row a, .pager-row span {
            display: block; padding: 6px 12px; border-radius: 6px; font-size: 13px;
            color: var(--text-sub); text-decoration: none; border: 1px solid var(--glass-border);
            transition: 0.3s;
        }
        .pager-row a:hover { border-color: var(--primary); color: var(--primary); }
        .pager-row span { background: var(--primary); color: #fff; border-color: var(--primary); font-weight: 700; }
    </style>
</head>
<body>
    <button class="theme-toggle" id="btnTheme" onclick="toggleTheme()" type="button" style="position:fixed; top:85px; right:40px; z-index:900;">
        <i class="fas fa-moon" id="themeIcon"></i>
    </button>

    <canvas id="particle-canvas"></canvas>

    <form id="form1" runat="server">
    <asp:ScriptManager ID="ScriptManager1" runat="server"></asp:ScriptManager>

    <div class="navbar fade-in">
        <a href="Default.aspx" class="brand">
            <i class="fas fa-shield-alt fa-spin" style="animation-duration: 15s;"></i> UNIVERSE 
            <span style="font-weight:300; opacity:0.6; font-size:14px; margin-left:5px;">ADMIN CONSOLE</span>
        </a>
        <div class="nav-actions">
            <a href="Default.aspx" class="btn-back">
                <i class="fas fa-arrow-left"></i> Main Command
            </a>
            
            <div class="user-profile">
                <div class="user-avatar"><i class="fas fa-user-shield"></i></div>
                <div>
                    <div style="font-size:13px; font-weight:600;"><asp:Label ID="lblUser" runat="server"></asp:Label></div>
                    <div style="font-size:11px; opacity:0.6;">SYSTEM ROOT</div>
                </div>
            </div>

            <asp:Button ID="btnLogout" runat="server" Text="LOGOUT" OnClick="btnLogout_Click" CssClass="btn-logout" />
        </div>
    </div>

    <div class="main-container">
        
        <asp:UpdatePanel ID="UpdatePanel1" runat="server">
            <ContentTemplate>
                
                <div class="search-bar-container fade-in" style="animation-delay: 0.1s;">
                    <div class="search-group">
                        <asp:TextBox ID="txtSearch" runat="server" CssClass="cyber-search" placeholder="Search by Name or ID..." AutoPostBack="true" OnTextChanged="btnSearch_Click"></asp:TextBox>
                        <i class="fas fa-search search-icon"></i>
                    </div>
                    <div class="stats-capsule">
                        <div>TOTAL FACULTY: <asp:Label ID="lblCount" runat="server">0</asp:Label></div>
                    </div>
                    <a href="AddTeacher.aspx" class="btn-neon">
                        <i class="fas fa-user-plus"></i> New Profile
                    </a>
                </div>

                <div class="grid-container fade-in" style="animation-delay: 0.2s;">
                    <asp:GridView ID="gvTeachers" runat="server" AutoGenerateColumns="False" 
                        DataKeyNames="TeacherId" CssClass="cyber-grid" GridLines="None"
                        AllowPaging="True" PageSize="10" OnPageIndexChanging="gvTeachers_PageIndexChanging"
                        OnRowCommand="gvTeachers_RowCommand">
                        <Columns>
                            <%-- 工号 --%>
                            <asp:TemplateField HeaderText="EMPLOYEE ID">
                                <ItemTemplate>
                                    <span class="id-badge"><%# Eval("WorkNo") %></span>
                                </ItemTemplate>
                            </asp:TemplateField>

                            <asp:BoundField DataField="Name" HeaderText="FULL NAME" ItemStyle-Font-Bold="true" />
                            <asp:BoundField DataField="Phone" HeaderText="CONTACT INFO" />
                            
                            <%-- 操作 --%>
                            <asp:TemplateField HeaderText="ACTIONS" ItemStyle-Width="100px" ItemStyle-HorizontalAlign="Right">
                                <ItemTemplate>
                                    <div style="display:flex; gap:10px; justify-content:flex-end;">
                                        <%-- 删除 --%>
                                        <asp:LinkButton ID="btnDel" runat="server" CommandName="DelTeacher" 
                                            CommandArgument='<%# Eval("TeacherId") %>' CssClass="action-btn del"
                                            OnClientClick="return confirm('WARNING: Confirm deletion of faculty record?');"
                                            ToolTip="Delete Record">
                                            <i class="fas fa-trash-alt"></i>
                                        </asp:LinkButton>
                                    </div>
                                </ItemTemplate>
                            </asp:TemplateField>
                        </Columns>
                        <PagerStyle CssClass="pager-row" HorizontalAlign="Right" />
                        <EmptyDataTemplate>
                            <div style="padding:60px; text-align:center; color:var(--text-sub);">
                                <i class="fas fa-user-slash" style="font-size:40px; margin-bottom:15px; opacity:0.5;"></i>
                                <p>No faculty records found matching query.</p>
                            </div>
                        </EmptyDataTemplate>
                    </asp:GridView>
                </div>

            </ContentTemplate>
        </asp:UpdatePanel>

    </div>
    </form>

    <script>
        // === 核心：主题与粒子引擎 ===
        const html = document.documentElement;
        const themeIcon = document.getElementById('themeIcon');
        const savedTheme = localStorage.getItem('theme') || 'dark';
        applyTheme(savedTheme);

        function toggleTheme() {
            const current = html.getAttribute('data-theme');
            const target = current === 'dark' ? 'light' : 'dark';
            document.body.style.transition = 'background 0.6s ease, color 0.6s ease';
            applyTheme(target);
            localStorage.setItem('theme', target);
        }

        function applyTheme(theme) {
            html.setAttribute('data-theme', theme);
            themeIcon.className = theme === 'dark' ? 'fas fa-moon' : 'fas fa-sun';
        }

        const canvas = document.getElementById('particle-canvas');
        const ctx = canvas.getContext('2d');
        let width, height, particles = [], mouse = { x: null, y: null };

        function getThemeColors() {
            const style = getComputedStyle(document.documentElement);
            const pColor = style.getPropertyValue('--p-color-rgb').trim().split(',');
            const lColor = style.getPropertyValue('--l-color-rgb').trim().split(',');
            return { p: pColor, l: lColor };
        }

        function resize() { width = canvas.width = window.innerWidth; height = canvas.height = window.innerHeight; }

        class Particle {
            constructor() {
                this.x = Math.random() * width; this.y = Math.random() * height;
                this.z = Math.random() * 1.5 + 0.5;
                this.vx = (Math.random() - 0.5) * 0.5 * this.z;
                this.vy = (Math.random() - 0.5) * 0.5 * this.z;
                this.size = Math.random() * 2 * this.z;
            }
            update() {
                this.x += this.vx; this.y += this.vy;
                if (mouse.x != null) {
                    let dx = mouse.x - this.x; let dy = mouse.y - this.y;
                    let distance = Math.sqrt(dx*dx + dy*dy);
                    if(distance < 250) {
                        const force = (250 - distance) / 250;
                        this.vx += (dx/distance) * force * 0.02 * this.z;
                        this.vy += (dy/distance) * force * 0.02 * this.z;
                    }
                }
                if (this.x < 0 || this.x > width) this.vx *= -1;
                if (this.y < 0 || this.y > height) this.vy *= -1;
            }
            draw(colors) {
                ctx.beginPath(); ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
                ctx.fillStyle = `rgba(${colors.p[0]}, ${colors.p[1]}, ${colors.p[2]}, ${0.5 * this.z})`; ctx.fill();
            }
        }

        function initParticles() { particles = []; for (let i = 0; i < 80; i++) particles.push(new Particle()); }

        function animate() {
            ctx.clearRect(0, 0, width, height); const colors = getThemeColors();
            for (let i = 0; i < particles.length; i++) {
                particles[i].update(); particles[i].draw(colors);
                for (let j = i + 1; j < particles.length; j++) {
                    let dx = particles[i].x - particles[j].x; let dy = particles[i].y - particles[j].y;
                    let distance = Math.sqrt(dx*dx + dy*dy);
                    if (distance < 100) {
                        ctx.beginPath();
                        let opacity = (1 - distance/100) * 0.4 * particles[i].z;
                        ctx.strokeStyle = `rgba(${colors.l[0]}, ${colors.l[1]}, ${colors.l[2]}, ${opacity})`;
                        ctx.lineWidth = 0.5 * particles[i].z;
                        ctx.moveTo(particles[i].x, particles[i].y); ctx.lineTo(particles[j].x, particles[j].y); ctx.stroke();
                    }
                }
            }
            requestAnimationFrame(animate);
        }

        window.addEventListener('resize', () => { resize(); initParticles(); });
        window.addEventListener('mousemove', (e) => { mouse.x = e.x; mouse.y = e.y; });
        window.addEventListener('mouseout', () => { mouse.x = null; mouse.y = null; });
        resize(); initParticles(); animate();
    </script>
</body>
</html>