﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

public partial class TeacherList : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // 权限验证
        if (Session["Role"] == null || Session["Role"].ToString() != "Admin")
            Response.Redirect("Login.aspx");

        if (!IsPostBack)
        {
            lblUser.Text = Session["User"] != null ? Session["User"].ToString() : "Admin";
            BindData();
        }
    }

    private void BindData(string search = "")
    {
        string sql = "SELECT TeacherId, WorkNo, Name, Phone FROM Teachers WHERE 1=1";

        if (!string.IsNullOrEmpty(search))
        {
            sql += " AND (Name LIKE @s OR WorkNo LIKE @s)";
        }

        sql += " ORDER BY WorkNo ASC";

        DataTable dt;
        if (!string.IsNullOrEmpty(search))
        {
            dt = SqlHelper.ExecuteQuery(sql, new SqlParameter("@s", "%" + search + "%"));
        }
        else
        {
            dt = SqlHelper.ExecuteQuery(sql);
        }

        gvTeachers.DataSource = dt;
        gvTeachers.DataBind();

        // 更新统计数
        lblCount.Text = dt.Rows.Count.ToString();
    }

    // 搜索事件
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        BindData(txtSearch.Text.Trim());
    }

    // 分页事件
    protected void gvTeachers_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvTeachers.PageIndex = e.NewPageIndex;
        BindData(txtSearch.Text.Trim());
    }

    // 删除逻辑
    protected void gvTeachers_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "DelTeacher")
        {
            int id = Convert.ToInt32(e.CommandArgument);

            // 安全删除流程：
            // 1. 删除该教师所有课程的选课记录
            string sqlDelScores = @"DELETE FROM Scores WHERE CourseId IN (SELECT CourseId FROM Courses WHERE TeacherId=@id)";
            SqlHelper.ExecuteNonQuery(sqlDelScores, new SqlParameter("@id", id));

            // 2. 删除该教师的所有课程
            string sqlDelCourses = "DELETE FROM Courses WHERE TeacherId=@id";
            SqlHelper.ExecuteNonQuery(sqlDelCourses, new SqlParameter("@id", id));

            // 3. 删除教师档案
            string sqlDelTeacher = "DELETE FROM Teachers WHERE TeacherId=@id";
            SqlHelper.ExecuteNonQuery(sqlDelTeacher, new SqlParameter("@id", id));

            BindData(txtSearch.Text.Trim());
        }
    }

    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session.Clear();
        Response.Redirect("Login.aspx");
    }
}